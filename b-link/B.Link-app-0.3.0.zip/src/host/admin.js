'use strict';
// Administrator control: one passphrase (scrypt hash, never stored in clear), an idle-timeout
// session, and an append-only audit trail. Every mutating IPC call in main.js goes through here.
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const SCRYPT = Object.freeze({ N: 16384, r: 8, p: 1 });
const KEYLEN = 32;
const MIN_PASSPHRASE = 12;
const ok = () => ({ ok: true, errors: [] });
const fail = (...errors) => ({ ok: false, errors });

class Admin {
  constructor(root, { now = () => Date.now(), idleMs = 10 * 60 * 1000 } = {}) {
    this.file = path.join(root, 'admin.json');
    this.now = now;
    this.idleMs = idleMs;
    this.expires = 0;
  }

  isSetUp() {
    return fs.existsSync(this.file);
  }

  isUnlocked() {
    if (this.expires && this.now() < this.expires) return true;
    this.expires = 0;
    return false;
  }

  touch() {
    if (this.isUnlocked()) this.expires = this.now() + this.idleMs;
  }

  setUp(passphrase) {
    if (this.isSetUp()) return fail('ALREADY_SET_UP');
    if (typeof passphrase !== 'string' || passphrase.length < MIN_PASSPHRASE) return fail('PASSPHRASE_TOO_SHORT');
    const salt = crypto.randomBytes(16);
    const hash = crypto.scryptSync(passphrase, salt, KEYLEN, SCRYPT);
    fs.writeFileSync(this.file, JSON.stringify({ v: 1, salt: salt.toString('base64'), hash: hash.toString('base64') }), { mode: 0o600 });
    this.expires = this.now() + this.idleMs;
    return ok();
  }

  unlock(passphrase) {
    if (!this.isSetUp()) return fail('NOT_SET_UP');
    let rec;
    try {
      rec = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch {
      return fail('ADMIN_FILE_CORRUPT');
    }
    const salt = Buffer.from(rec.salt, 'base64');
    const want = Buffer.from(rec.hash, 'base64');
    const got = crypto.scryptSync(String(passphrase ?? ''), salt, want.length, SCRYPT);
    if (!crypto.timingSafeEqual(got, want)) return fail('BAD_PASSPHRASE');
    this.expires = this.now() + this.idleMs;
    return ok();
  }

  lock() {
    this.expires = 0;
  }
}

// Records what happened, never secrets: callers pass only whitelisted detail fields.
class AuditLog {
  constructor(root, { now = () => Date.now() } = {}) {
    this.file = path.join(root, 'audit.jsonl');
    this.now = now;
  }

  record(event, detail = {}) {
    const line = JSON.stringify({ t: new Date(this.now()).toISOString(), event, ...detail });
    fs.appendFileSync(this.file, line + '\n', { mode: 0o600 });
  }

  recent(limit = 50) {
    if (!fs.existsSync(this.file)) return [];
    return fs
      .readFileSync(this.file, 'utf8')
      .split('\n')
      .filter(Boolean)
      .slice(-limit)
      .map((l) => {
        try {
          return JSON.parse(l);
        } catch {
          return { event: 'CORRUPT_LINE' };
        }
      });
  }
}

module.exports = { Admin, AuditLog, MIN_PASSPHRASE };
