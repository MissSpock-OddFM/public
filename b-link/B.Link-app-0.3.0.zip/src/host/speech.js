'use strict';
// Local speech for the terminal: Piper voices (text to speech) and Whisper tiny.en (speech to text),
// both run in-process by sherpa-onnx (small int8 models, no GPU, no network, no cloud).
// Nothing here is reachable by cartridges; only the shell and the main process call it.
const fs = require('node:fs');
const path = require('node:path');

const MAX_TEXT = 1500;
const MAX_SECONDS = 30;
const VOICE_RE = /^[A-Za-z0-9_-]{3,60}$/;

// Turn chat text into something that sounds right when spoken.
function cleanForSpeech(text) {
  return String(text || '')
    .replace(/```[\s\S]*?```/g, ' code block. ')
    .replace(/https?:\/\/\S+/g, ' link ')
    .replace(/[*_`#>~|]+/g, ' ')
    .replace(/\[(.*?)\]\(.*?\)/g, '$1')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, MAX_TEXT);
}

function floatToWav(samples, rate) {
  const b = Buffer.alloc(44 + samples.length * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + samples.length * 2, 4); b.write('WAVEfmt ', 8);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(rate, 24); b.writeUInt32LE(rate * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34);
  b.write('data', 36); b.writeUInt32LE(samples.length * 2, 40);
  for (let i = 0; i < samples.length; i++) {
    b.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(samples[i] * 32767))), 44 + i * 2);
  }
  return b;
}

class Speech {
  // dir holds voices/<voiceId>/{*.onnx,tokens.txt,espeak-ng-data} and whisper/{*-encoder.int8.onnx,*-decoder.int8.onnx,*-tokens.txt}
  constructor(dir, { load = () => require('sherpa-onnx-node') } = {}) {
    this.dir = dir;
    this.load = load;
    this.sherpa = null;
    this.tts = new Map(); // voiceId -> OfflineTts
    this.rec = null;
  }

  _sherpa() {
    if (!this.sherpa) this.sherpa = this.load();
    return this.sherpa;
  }

  listVoices() {
    const vdir = path.join(this.dir, 'voices');
    let names = [];
    try { names = fs.readdirSync(vdir); } catch { return []; }
    return names.filter((n) => VOICE_RE.test(n) && this._voiceFiles(n)).sort();
  }

  _voiceFiles(id) {
    const d = path.join(this.dir, 'voices', id);
    try {
      const onnx = fs.readdirSync(d).find((f) => f.endsWith('.onnx'));
      const tokens = path.join(d, 'tokens.txt');
      const data = path.join(d, 'espeak-ng-data');
      if (onnx && fs.existsSync(tokens) && fs.existsSync(data)) return { model: path.join(d, onnx), tokens, dataDir: data };
    } catch { /* not installed */ }
    return null;
  }

  _whisperFiles() {
    const d = path.join(this.dir, 'whisper');
    try {
      const f = fs.readdirSync(d);
      const encoder = f.find((x) => /-encoder\.int8\.onnx$/.test(x));
      const decoder = f.find((x) => /-decoder\.int8\.onnx$/.test(x));
      const tokens = f.find((x) => /-tokens\.txt$/.test(x));
      if (encoder && decoder && tokens) return { encoder: path.join(d, encoder), decoder: path.join(d, decoder), tokens: path.join(d, tokens) };
    } catch { /* not installed */ }
    return null;
  }

  status() {
    return { voices: this.listVoices(), tts: this.listVoices().length > 0, stt: !!this._whisperFiles() };
  }

  async speak(text, voiceId, speed = 1.0) {
    const clean = cleanForSpeech(text);
    if (!clean) return { ok: false, error: 'NOTHING_TO_SAY' };
    const files = typeof voiceId === 'string' && VOICE_RE.test(voiceId) ? this._voiceFiles(voiceId) : null;
    if (!files) return { ok: false, error: 'VOICE_NOT_INSTALLED' };
    try {
      let tts = this.tts.get(voiceId);
      if (!tts) {
        tts = new (this._sherpa().OfflineTts)({
          model: { vits: { model: files.model, tokens: files.tokens, dataDir: files.dataDir }, debug: false, numThreads: 2, provider: 'cpu' },
          maxNumSentences: 1,
        });
        this.tts.set(voiceId, tts);
      }
      // enableExternalBuffer:false is required inside Electron (external ArrayBuffers are not allowed there).
      const req = { enableExternalBuffer: false, text: clean, sid: 0, speed: Number(speed) >= 0.6 && Number(speed) <= 1.6 ? Number(speed) : 1.0 };
      const a = tts.generate(req); // synchronous on purpose: this runs inside the speech worker thread
      if (!a || !a.samples || a.samples.length === 0) return { ok: false, error: 'SPEECH_FAILED' };
      return { ok: true, wav: floatToWav(a.samples, a.sampleRate), seconds: a.samples.length / a.sampleRate };
    } catch {
      return { ok: false, error: 'SPEECH_FAILED' };
    }
  }

  // samples: Float32Array of mono audio; returns the transcript.
  async listen(samples, sampleRate) {
    const files = this._whisperFiles();
    if (!files) return { ok: false, error: 'LISTENER_NOT_INSTALLED' };
    const rate = Number(sampleRate);
    if (!(samples && samples.length > 0) || !(rate >= 8000 && rate <= 48000)) return { ok: false, error: 'BAD_AUDIO' };
    if (samples.length / rate > MAX_SECONDS) return { ok: false, error: 'TOO_LONG' };
    try {
      if (!this.rec) {
        this.rec = new (this._sherpa().OfflineRecognizer)({
          featConfig: { sampleRate: 16000, featureDim: 80 },
          modelConfig: { whisper: { encoder: files.encoder, decoder: files.decoder, language: 'en', task: 'transcribe', tailPaddings: -1 }, tokens: files.tokens, numThreads: 2, provider: 'cpu', debug: 0 },
        });
      }
      const stream = this.rec.createStream();
      stream.acceptWaveform({ samples: Float32Array.from(samples), sampleRate: rate });
      this.rec.decode(stream);
      const text = String((this.rec.getResult(stream) || {}).text || '').replace(/\s+/g, ' ').trim();
      return { ok: true, text: text.slice(0, 2000) };
    } catch {
      return { ok: false, error: 'LISTEN_FAILED' };
    }
  }
}

module.exports = { Speech, cleanForSpeech, floatToWav, MAX_SECONDS };
