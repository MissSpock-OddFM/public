'use strict';
const path = require('node:path');
const fs = require('node:fs');
const { app, BrowserWindow, Menu, ipcMain, dialog, protocol, session, safeStorage } = require('electron');
const { Library } = require('./host/library');
const { LlmBridge } = require('./host/bridge');
const { makeResponsesProvider, makeModelLister, pickModel, ENDPOINTS } = require('./host/providers');
const { Admin, AuditLog } = require('./host/admin');
const { Settings } = require('./host/settings');
const { LIMITS } = require('./cartridge/verify');
const { buildCartridgeCsp } = require('./host/csp');
const { runSeed } = require('./host/seed');
const { PERSONA, MAX_TURNS } = require('./host/betty');
const { SpeechService } = require('./host/speech-service');

protocol.registerSchemesAsPrivileged([
  { scheme: 'blink-cart', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

// One data folder in every mode (npm start, installer, portable), so saves and admin settings survive.
app.setPath('userData', path.join(app.getPath('appData'), 'B.Link'));
// Appliance look: no scrollbars anywhere, including inside cartridges (wheel, keys and touch still scroll).
app.commandLine.appendSwitch('hide-scrollbars');

let admin;
let audit;
let settings;
let library;
let speech;
let mainWin = null;
let bridge;

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    fullscreen: true, // no title bar, no taskbar. F11 toggles.
    autoHideMenuBar: true,
    backgroundColor: '#000000',
    title: 'B.Link // Labyrinth Terminal',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  mainWin = win;
  win.on('closed', () => { mainWin = null; });
  // Terminal keys, caught here so they work even while a cartridge has focus.
  //   F11 full screen   F9 hold to dictate   F10 hold to dictate and send   F8 stop speaking
  win.webContents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown' && input.type !== 'keyUp') return;
    const down = input.type === 'keyDown';
    if (input.key === 'F11') {
      event.preventDefault();
      if (down && !input.isAutoRepeat) win.setFullScreen(!win.isFullScreen());
    } else if (input.key === 'F9' || input.key === 'F10') {
      event.preventDefault();
      pttKey(win, input, down);
    } else if (input.key === 'F8') {
      event.preventDefault();
      if (down) win.webContents.send('speech:stop');
    }
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

// Push to talk that survives a missing key-up (some Windows focus states drop it):
// hold = record until release; tap = toggle (tap again to stop); a held key that stops repeating counts as released.
const ptt = { active: false, key: null, t0: 0, timer: null };
function pttStop(win) {
  clearTimeout(ptt.timer); clearTimeout(ptt.max); ptt.timer = null;
  if (!ptt.active) return;
  ptt.active = false;
  if (win && !win.isDestroyed()) win.webContents.send('speech:ptt', { down: false, send: ptt.key === 'F10' });
}
function pttKey(win, input, down) {
  if (down && input.isAutoRepeat) {
    if (ptt.active && input.key === ptt.key) { clearTimeout(ptt.timer); ptt.timer = setTimeout(() => pttStop(win), 400); }
    return;
  }
  if (down) {
    if (ptt.active) return pttStop(win);
    Object.assign(ptt, { active: true, key: input.key, t0: Date.now() });
    clearTimeout(ptt.max); ptt.max = setTimeout(() => pttStop(win), 40000);
    win.webContents.send('speech:ptt', { down: true, send: input.key === 'F10' });
  } else if (ptt.active && input.key === ptt.key && Date.now() - ptt.t0 >= 450) {
    pttStop(win);
  }
}

// Every administrator write needs an unlocked session and leaves an audit line with no secrets.
function gated(name, fn, detail = () => ({}), after = () => ({})) {
  return async (_event, ...args) => {
    if (!admin.isUnlocked()) return { ok: false, errors: ['ADMIN_LOCKED'] };
    admin.touch();
    const r = await fn(...args);
    audit.record(`admin.${name}`, { ok: r.ok === true, errors: r.errors || [], ...detail(...args), ...after(r) });
    return r;
  };
}

async function updateFromPicker() {
  const r = await dialog.showOpenDialog({
    title: 'Update cartridge',
    filters: [{ name: 'Cartridge ZIP', extensions: ['zip'] }],
    properties: ['openFile'],
  });
  if (r.canceled || r.filePaths.length === 0) return { ok: false, errors: ['CANCELLED'] };
  const file = r.filePaths[0];
  if (fs.statSync(file).size > LIMITS.maxTotalBytes) return { ok: false, errors: ['ZIP_TOO_LARGE'] };
  return library.updateFromZip(fs.readFileSync(file));
}

async function installFromPicker() {
  const r = await dialog.showOpenDialog({
    title: 'Install cartridge',
    filters: [{ name: 'Cartridge ZIP', extensions: ['zip'] }],
    properties: ['openFile'],
  });
  if (r.canceled || r.filePaths.length === 0) return { ok: false, errors: ['CANCELLED'] };
  const file = r.filePaths[0];
  if (fs.statSync(file).size > LIMITS.maxTotalBytes) return { ok: false, errors: ['ZIP_TOO_LARGE'] };
  return library.installFromZip(fs.readFileSync(file));
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  // The microphone is for the B.Link shell page only. Cartridges (blink-cart://) get nothing.
  const shellOnlyMic = (permission, url) => permission === 'media' && typeof url === 'string' && url.startsWith('file://');
  session.defaultSession.setPermissionRequestHandler((_wc, permission, cb, details) => cb(shellOnlyMic(permission, details && details.requestingUrl)));
  session.defaultSession.setPermissionCheckHandler((_wc, permission, origin) => shellOnlyMic(permission, origin));

  const root = app.getPath('userData');
  admin = new Admin(root);
  audit = new AuditLog(root);
  settings = new Settings(root, {
    encrypt: (s) => {
      if (!safeStorage.isEncryptionAvailable()) throw new Error('ENCRYPTION_UNAVAILABLE');
      return safeStorage.encryptString(s);
    },
    decrypt: (b) => safeStorage.decryptString(b),
  });
  library = new Library(root, { settings });
  admin.setIdleMinutes(settings.getLockMinutes());
  speech = new SpeechService(path.join(root, 'speech'));
  runSeed({ dir: path.join(app.getAppPath(), 'seed'), library, settings, audit });
  // The Miss Flower command cartridge is not part of B.Link. Earlier builds seeded it; take it back out once.
  try { if (library.getManifest('phantomtronix-command')) { const r = library.remove('phantomtronix-command'); audit.record('migrate.remove', { id: 'phantomtronix-command', ok: r.ok === true }); } } catch {}
  bridge = new LlmBridge({
    library,
    providers: {
      openai: makeResponsesProvider(ENDPOINTS.openai),
      xai: makeResponsesProvider(ENDPOINTS.xai),
    },
    modelResolver: async (name, apiKey, signal) => pickModel(name, await makeModelLister(ENDPOINTS[name])({ apiKey, signal })),
    isKilled: () => settings.killSwitch(),
    onEvent: (d) => audit.record('bridge', d),
  });

  protocol.handle('blink-cart', (req) => {
    const url = new URL(req.url);
    const rel = decodeURIComponent(url.pathname.replace(/^\//, ''));
    const hit = library.pinnedFile(url.hostname, rel);
    if (!hit) return new Response('Not found', { status: 404 });
    return new Response(hit.data, {
      headers: {
        'content-type': hit.mime,
        'content-security-policy': buildCartridgeCsp(settings.getEmbeds(url.hostname) || []),
        'x-content-type-options': 'nosniff',
        'cache-control': 'no-store',
      },
    });
  });

  // Admin session
  ipcMain.handle('admin:status', () => ({ setUp: admin.isSetUp(), unlocked: admin.isUnlocked() }));
  ipcMain.handle('admin:setup', (_e, pass) => {
    const r = admin.setUp(pass);
    audit.record('admin.setup', { ok: r.ok, errors: r.errors });
    return r;
  });
  ipcMain.handle('admin:unlock', (_e, pass) => {
    const r = admin.unlock(pass);
    audit.record('admin.unlock', { ok: r.ok, errors: r.errors });
    return r;
  });
  ipcMain.handle('admin:lock', () => {
    admin.lock();
    audit.record('admin.lock', {});
    return { ok: true, errors: [] };
  });

  // Reads (admin only, no secrets in the result)
  ipcMain.handle('settings:status', () => (admin.isUnlocked() ? { ok: true, ...settings.status() } : { ok: false, errors: ['ADMIN_LOCKED'] }));
  ipcMain.handle('audit:recent', (_e, n) => (admin.isUnlocked()
    ? { ok: true, errors: [], lines: audit.recent(Math.min(Number(n) || 50, 200)) }
    : { ok: false, errors: ['ADMIN_LOCKED'] }));

  // Cartridge list is open to the shelf; it carries no secrets.
  ipcMain.handle('library:list', () => library.listInstalled());

  // Admin writes
  ipcMain.handle('settings:killswitch', gated('killswitch', (on) => settings.setKillSwitch(on), (on) => ({ on: on === true })));
  ipcMain.handle('settings:provider', gated(
    'provider',
    (name, p) => settings.setProvider(String(name), p || {}),
    (name, p) => ({ name: String(name), modelSet: !!(p && p.model), keyChanged: !!(p && p.apiKey !== undefined) }),
  ));
  ipcMain.handle('settings:test', gated(
    'provider.test',
    (name) => bridge.selfTest(String(name)),
    (name) => ({ name: String(name) }),
    (r) => ({ result: r.ok ? 'OK' : r.error }),
  ));
  ipcMain.handle('library:install', gated('install', () => installFromPicker()));
  ipcMain.handle('library:update', gated(
    'update',
    () => updateFromPicker(),
    () => ({}),
    (r) => ({ id: r.id, from: r.from, to: r.to, newCapabilities: r.newCapabilities }),
  ));
  ipcMain.handle('library:rollback', gated('rollback', (id) => library.rollback(String(id)), (id) => ({ id: String(id) })));
  ipcMain.handle('embeds:set', gated(
    'embeds',
    (id, list) => {
      if (!library.getManifest(String(id))) return { ok: false, errors: ['NOT_INSTALLED'] };
      return settings.setEmbeds(String(id), Array.isArray(list) ? list.map(String) : []);
    },
    (id, list) => ({ id: String(id), embeds: Array.isArray(list) ? list.map(String) : [] }),
  ));
  ipcMain.handle('library:remove', gated('remove', (id) => library.remove(String(id)), (id) => ({ id: String(id) })));
  ipcMain.handle('library:setEnabled', gated(
    'enable',
    (id, on) => {
      if (!library.getManifest(String(id))) return { ok: false, errors: ['NOT_INSTALLED'] };
      return settings.setDisabled(String(id), on !== true);
    },
    (id, on) => ({ id: String(id), enabled: on === true }),
  ));
  ipcMain.handle('grants:set', gated(
    'grant',
    (id, cap, v) => library.setGrant(String(id), String(cap), v === true),
    (id, cap, v) => ({ id: String(id), cap: String(cap), value: v === true }),
  ));

  // Cartridge calls: the kill switch and the disable flag are checked inside the bridge.
  ipcMain.handle('bridge:req', async (_e, { cartridgeId, msg }) => {
    if (msg && msg.op === 'bridge.chat') audit.record('chat.start', { cartridgeId });
    const res = await bridge.handle(cartridgeId, msg);
    if (msg && msg.op === 'bridge.chat') audit.record('chat.done', { cartridgeId, ok: !!(res && res.ok), error: res && res.error ? String(res.error.code || res.error) : undefined, chars: res && res.result && typeof res.result.text === 'string' ? res.result.text.length : 0 });
    // Read replies aloud for any chat cartridge, with no change to the cartridge.
    if (res && res.ok && msg && msg.op === 'bridge.chat' && res.result && typeof res.result.text === 'string') speakReply(res.result.text);
    return res;
  });

  // BETTY, the built-in assistant (host-side, not a cartridge).
  ipcMain.handle('betty:ask', async (_e, turns) => {
    const list = (Array.isArray(turns) ? turns : []).slice(-MAX_TURNS).map((t) => ({ role: t && t.role === 'assistant' ? 'assistant' : 'user', content: String((t && t.content) || '').slice(0, 4000) })).filter((t) => t.content);
    audit.record('betty.ask', { turns: list.length });
    const res = await bridge.hostChat({ messages: list, instructions: PERSONA });
    audit.record('betty.reply', { ok: res.ok === true, error: res.ok ? undefined : String(res.error) });
    if (res.ok) speakReply(res.result.text);
    return res.ok ? { ok: true, text: res.result.text } : { ok: false, error: res.error };
  });

  // Speech: local Piper voice and Whisper tiny. Open to the shell; admin-gated to change.
  const speechStatus = () => ({ ...speech.status(), ...settings.getSpeech() });
  async function speakReply(text) {
    const pref = settings.getSpeech();
    if (!pref.readAloud || settings.killSwitch() || !mainWin) return;
    const r = await speech.speak(text, pref.voice, pref.speed);
    audit.record('speech.reply', { ok: !!r.ok, error: r.ok ? undefined : String(r.error), bytes: r.ok && r.wav ? r.wav.length : 0 });
    if (r.ok && mainWin) mainWin.webContents.send('speech:play', r.wav);
  }
  ipcMain.handle('speech:played', (_e, d) => { audit.record('speech.play', { ok: d && d.ok === true, error: d && d.error ? String(d.error).slice(0, 120) : undefined }); return { ok: true }; });
  ipcMain.handle('speech:status', () => ({ ok: true, ...speechStatus() }));
  ipcMain.handle('speech:say', async (_e, text) => {
    const pref = settings.getSpeech();
    const r = await speech.speak(String(text).slice(0, 600), pref.voice, pref.speed);
    if (!r.ok) return { ok: false, error: r.error };
    if (mainWin) mainWin.webContents.send('speech:play', r.wav);
    return { ok: true };
  });
  // Put dictated text into the focused text box of the cartridge on screen (or of the shell itself).
  // The host runs this in the frame, so it works across the cartridge sandbox and uses no clipboard.
  const TYPE_INTO_FOCUS = `(function (t, send) {
    var el = document.activeElement;
    if (!el || !(el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) return false;
    document.execCommand('insertText', false, t);
    if (send) {
      if (el.form && el.form.requestSubmit) el.form.requestSubmit();
      else el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    }
    return true;
  })`;
  ipcMain.handle('speech:listen', async (e, { samples, rate, send }) => {
    const r = await speech.listen(samples, rate);
    audit.record('speech.listen', { ok: !!r.ok, error: r.ok ? undefined : String(r.error), seconds: Math.round((samples && samples.length ? samples.length / (rate || 16000) : 0) * 10) / 10, chars: r.ok && r.text ? r.text.length : 0 });
    if (!r.ok) return { ok: false, error: r.error };
    let placed = false;
    if (r.text) {
      const frame = e.sender.mainFrame.framesInSubtree.find((f) => f.url.startsWith('blink-cart://')) || e.sender.mainFrame;
      try {
        placed = (await frame.executeJavaScript(`${TYPE_INTO_FOCUS}(${JSON.stringify(r.text)}, ${send === true})`)) === true;
      } catch { placed = false; }
    }
    return { ok: true, text: r.text, placed };
  });
  ipcMain.handle('speech:settings', gated(
    'speech',
    (patch) => {
      const p = patch && typeof patch === 'object' ? patch : {};
      if (p.voice !== undefined && !speech.listVoices().includes(p.voice)) return { ok: false, errors: ['VOICE_NOT_INSTALLED'] };
      return settings.setSpeech(p);
    },
    (patch) => ({ voice: patch && patch.voice, readAloud: patch && patch.readAloud, speed: patch && patch.speed }),
  ));
  ipcMain.handle('admin:lockmins', gated(
    'lockmins',
    (m) => { const r = settings.setLockMinutes(m); if (r.ok) admin.setIdleMinutes(settings.getLockMinutes()); return r; },
    (m) => ({ minutes: Number(m) }),
  ));
  ipcMain.handle('app:version', () => app.getVersion());
  ipcMain.handle('app:quit', () => { app.quit(); });

  createWindow();
});

app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => { if (speech) speech.close(); });
