'use strict';
// Builds the Content Security Policy for a cartridge document. The base policy allows nothing
// outside the cartridge's own pinned files. The only way to open it wider is a named preset with
// a fixed list of addresses: neither a cartridge nor an admin can type a free-form address.
const BASE = Object.freeze({
  'default-src': ["'none'"],
  'script-src': ["'self'"],
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': ["'self'", 'data:', 'blob:'],
  'media-src': ["'self'", 'blob:', 'data:'],
  'font-src': ["'self'"],
  'connect-src': ["'self'"],
  'frame-src': ["'none'"],
  'form-action': ["'none'"],
  'base-uri': ["'none'"],
});

// Mixcloud's official widget: one script, plus a frame that redirects to its player host.
const EMBED_PRESETS = Object.freeze({
  mixcloud: Object.freeze({
    label: 'Mixcloud audio player',
    script: Object.freeze(['https://widget.mixcloud.com']),
    frame: Object.freeze(['https://www.mixcloud.com', 'https://player-widget.mixcloud.com']),
  }),
});

function buildCartridgeCsp(embeds = []) {
  const d = Object.fromEntries(Object.entries(BASE).map(([k, v]) => [k, [...v]]));
  const frames = [];
  for (const name of embeds) {
    if (typeof name !== 'string' || !Object.hasOwn(EMBED_PRESETS, name)) continue;
    d['script-src'].push(...EMBED_PRESETS[name].script);
    frames.push(...EMBED_PRESETS[name].frame);
  }
  if (frames.length) d['frame-src'] = [...new Set(frames)];
  return Object.entries(d).map(([k, v]) => `${k} ${v.join(' ')}`).join('; ');
}

module.exports = { buildCartridgeCsp, EMBED_PRESETS };
