'use strict';
// Operator-side seeding. ZIPs in the app's seed folder are verified like any install. A newer ZIP
// for an installed cartridge updates it in place. seed-policy.json supplies a starting embed choice
// for a cartridge only while no admin has made one, so an admin's decision always wins.
const fs = require('node:fs');
const path = require('node:path');
const { LIMITS } = require('../cartridge/verify');
const { EMBED_PRESETS } = require('./csp');

function runSeed({ dir, library, settings, audit }) {
  let names = [];
  try {
    names = fs.readdirSync(dir).filter((n) => n.toLowerCase().endsWith('.zip')).sort();
  } catch {
    return;
  }
  for (const n of names) {
    try {
      const file = path.join(dir, n);
      if (fs.statSync(file).size > LIMITS.maxTotalBytes) {
        audit.record('seed.refused', { file: n, errors: ['ZIP_TOO_LARGE'] });
        continue;
      }
      const buf = fs.readFileSync(file);
      const r = library.installFromZip(buf);
      if (r.ok) {
        audit.record('seed.install', { id: r.id });
      } else if (r.errors.includes('ALREADY_INSTALLED')) {
        const u = library.updateFromZip(buf);
        if (u.ok) audit.record('seed.update', { id: u.id, from: u.from, to: u.to, newCapabilities: u.newCapabilities });
        else if (!u.errors.includes('NOT_NEWER')) audit.record('seed.refused', { file: n, errors: u.errors });
      } else {
        audit.record('seed.refused', { file: n, errors: r.errors });
      }
    } catch {
      audit.record('seed.error', { file: n });
    }
  }

  let policy;
  try {
    policy = JSON.parse(fs.readFileSync(path.join(dir, 'seed-policy.json'), 'utf8'));
  } catch {
    return;
  }
  if (!policy || typeof policy !== 'object' || Array.isArray(policy)) return;
  for (const [id, p] of Object.entries(policy)) {
    if (!library.getManifest(id) || settings.getEmbeds(id) !== null) continue;
    const list = p && Array.isArray(p.embeds)
      ? p.embeds.filter((e) => typeof e === 'string' && Object.hasOwn(EMBED_PRESETS, e))
      : [];
    const r = settings.setEmbeds(id, list);
    audit.record('seed.policy', { id, embeds: list, ok: r.ok });
  }
}

module.exports = { runSeed };
