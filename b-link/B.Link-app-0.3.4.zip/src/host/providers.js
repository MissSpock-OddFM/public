'use strict';
// Trusted-host provider adapters. Only the host calls these; cartridges never see URLs,
// keys or raw provider responses. Fails closed: every error maps to a bridge code.
const ENDPOINTS = Object.freeze({
  openai: 'https://api.openai.com',
  xai: 'https://api.x.ai',
});

function providerError(code) {
  const e = new Error(code);
  e.code = code;
  return e;
}

function extractText(data) {
  if (data && typeof data.output_text === 'string') return data.output_text;
  const parts = [];
  for (const item of (data && Array.isArray(data.output) ? data.output : [])) {
    for (const c of (item && Array.isArray(item.content) ? item.content : [])) {
      if (c && c.type === 'output_text' && typeof c.text === 'string') parts.push(c.text);
    }
  }
  return parts.join('');
}

// Responses API adapter: POST {baseUrl}/v1/responses
function makeResponsesProvider(baseUrl, { fetchImpl = (...a) => globalThis.fetch(...a) } = {}) {
  return async function callProvider({ apiKey, model, messages, instructions, signal }) {
    let res;
    try {
      res = await fetchImpl(`${baseUrl}/v1/responses`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
        body: JSON.stringify(instructions ? { model, input: messages, instructions } : { model, input: messages }),
        redirect: 'error',
        signal,
      });
    } catch {
      throw providerError('PROVIDER_REQUEST_FAILED');
    }
    if (res.status === 401 || res.status === 403) throw providerError('PROVIDER_AUTH_FAILED');
    if (res.status === 429) throw providerError('PROVIDER_RATE_LIMIT');
    if (!res.ok) throw providerError('PROVIDER_REQUEST_FAILED');
    let data;
    try {
      data = await res.json();
    } catch {
      throw providerError('PROVIDER_REQUEST_FAILED');
    }
    const text = extractText(data);
    if (!text) throw providerError('PROVIDER_REQUEST_FAILED');
    return {
      text,
      usage: {
        input: Number(data.usage && data.usage.input_tokens) || 0,
        output: Number(data.usage && data.usage.output_tokens) || 0,
      },
    };
  };
}

// Choose a sensible default chat model from the provider's own model list, so nobody has to type one.
// Pure function: takes the /v1/models "data" array, returns an id or null.
const SKIP = /(audio|realtime|transcribe|tts|whisper|image|imagine|video|search|embed|moderation|instruct|codex|vision|dall|sora|speech|computer|deep-research|fast|mini|nano|lite|luna)/i;
function pickModel(provider, list) {
  const rows = (Array.isArray(list) ? list : [])
    .filter((m) => m && typeof m.id === 'string' && !SKIP.test(m.id) && !/-\d{4}-\d{2}-\d{2}$/.test(m.id) && !/-\d{4}$/.test(m.id));
  const ver = (id) => { const m = /(\d+(?:\.\d+)?)/.exec(id); return m ? parseFloat(m[1]) : 0; };
  const re = provider === 'xai' ? /^grok-\d/ : /^gpt-\d/;
  const c = rows.filter((m) => re.test(m.id));
  c.sort((a, b) => (ver(b.id) - ver(a.id)) || ((Number(b.created) || 0) - (Number(a.created) || 0)) || a.id.localeCompare(b.id));
  return c.length ? c[0].id : null;
}

// GET {baseUrl}/v1/models -> array of {id, created}
function makeModelLister(baseUrl, { fetchImpl = (...a) => globalThis.fetch(...a) } = {}) {
  return async function listModels({ apiKey, signal }) {
    let res;
    try {
      res = await fetchImpl(`${baseUrl}/v1/models`, { headers: { authorization: `Bearer ${apiKey}` }, redirect: 'error', signal });
    } catch {
      throw providerError('PROVIDER_REQUEST_FAILED');
    }
    if (res.status === 401 || res.status === 403) throw providerError('PROVIDER_AUTH_FAILED');
    if (res.status === 429) throw providerError('PROVIDER_RATE_LIMIT');
    if (!res.ok) throw providerError('PROVIDER_REQUEST_FAILED');
    try {
      const j = await res.json();
      return Array.isArray(j.data) ? j.data : [];
    } catch {
      throw providerError('PROVIDER_REQUEST_FAILED');
    }
  };
}

module.exports = { ENDPOINTS, makeResponsesProvider, makeModelLister, pickModel, extractText, providerError };
