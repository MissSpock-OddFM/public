'use strict';
// Main-thread front for the speech worker. Same calls as Speech, but heavy work happens in a worker thread.
// A crashed or stuck worker fails the call and is replaced on the next one.
const path = require('node:path');
const { Worker } = require('node:worker_threads');
const { Speech } = require('./speech');

class SpeechService {
  constructor(dir, { timeoutMs = 20000, workerFile = path.join(__dirname, 'speech-worker.js') } = {}) {
    this.dir = dir;
    this.timeoutMs = timeoutMs;
    this.workerFile = workerFile;
    this.local = new Speech(dir); // cheap folder listing only; never loads an engine
    this.worker = null;
    this.pending = new Map();
    this.seq = 0;
  }

  listVoices() { return this.local.listVoices(); }
  status() { return this.local.status(); }

  _start() {
    if (this.worker) return this.worker;
    const w = new Worker(this.workerFile, { workerData: { dir: this.dir } });
    const failAll = (error) => {
      for (const [, p] of this.pending) { clearTimeout(p.timer); p.resolve({ ok: false, error }); }
      this.pending.clear();
      if (this.worker === w) this.worker = null;
    };
    w.on('message', ({ id, r }) => {
      const p = this.pending.get(id);
      if (!p) return;
      clearTimeout(p.timer);
      this.pending.delete(id);
      p.resolve(r);
    });
    w.on('error', () => failAll('SPEECH_FAILED'));
    w.on('exit', () => failAll('SPEECH_FAILED'));
    this.worker = w;
    return w;
  }

  // One retry on a fresh worker if the engine stalls, so a stuck decode never leaves dictation dead.
  async _call(op, args) {
    const r = await this._once(op, args);
    return r.error === 'SPEECH_TIMEOUT' ? this._once(op, args) : r;
  }

  _once(op, args) {
    return new Promise((resolve) => {
      let w;
      try { w = this._start(); } catch { return resolve({ ok: false, error: 'SPEECH_FAILED' }); }
      const id = ++this.seq;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        resolve({ ok: false, error: 'SPEECH_TIMEOUT' });
        if (this.worker === w) { this.worker = null; w.terminate(); }
      }, this.timeoutMs);
      this.pending.set(id, { resolve, timer });
      w.postMessage({ id, op, args });
    });
  }

  speak(text, voiceId, speed) { return this._call('speak', [text, voiceId, speed]); }
  listen(samples, rate) { return this._call('listen', [samples, rate]); }
  close() { if (this.worker) this.worker.terminate(); this.worker = null; }
}

module.exports = { SpeechService };
