'use strict';
// Runs the heavy speech engines off the main thread so the terminal never freezes while it talks or listens.
const { parentPort, workerData } = require('node:worker_threads');
const { Speech } = require('./speech');

const sp = new Speech(workerData.dir);
parentPort.on('message', async ({ id, op, args }) => {
  let r;
  try {
    r = op === 'speak' ? await sp.speak(...args) : await sp.listen(...args);
  } catch {
    r = { ok: false, error: 'SPEECH_FAILED' };
  }
  parentPort.postMessage({ id, r });
});
