'use strict';
// B.Link cartridge verifier. Pure logic: no Electron, no writes to disk.
// Implements the captured V2 package contract (PANELS_PLUGIN_MANIFEST_V2) from the
// City Link developer kit (DOCS/01). This build accepts runtime "web" only.
const crypto = require('node:crypto');
const AdmZip = require('adm-zip');

const SCHEMA = 'PANELS_PLUGIN_MANIFEST_V2';
const LIMITS = Object.freeze({
  maxEntries: 200,
  maxTotalBytes: 32 * 1024 * 1024,
  maxFileBytes: 12 * 1024 * 1024,
  maxNameLength: 240,
  maxManifestBytes: 64 * 1024,
});
const ID_RE = /^[a-z0-9][a-z0-9-]{1,62}$/;
const SHA_RE = /^[0-9a-f]{64}$/;
const KNOWN_CAPABILITIES = Object.freeze(['llm.chat']);
const SUPPORTED_RUNTIMES = Object.freeze(['web']);

function sha256Hex(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

// Windows device names, trailing dots or spaces, and ":" (alternate data streams) are refused on every
// platform, so one cartridge behaves the same on Ubuntu, Windows and Android.
const WIN_RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
const BAD_SEGMENT_CHARS = /[<>"|?*\x00-\x1f]/;

function isSafeRelPath(p) {
  if (typeof p !== 'string' || p.length === 0 || p.length > LIMITS.maxNameLength) return false;
  if (p.startsWith('/') || p.includes('\\') || p.includes(':')) return false;
  return p.split('/').every((seg) => (
    seg !== '' && seg !== '.' && seg !== '..' &&
    !/[. ]$/.test(seg) && !WIN_RESERVED.test(seg) && !BAD_SEGMENT_CHARS.test(seg)
  ));
}

function isSymlink(entry) {
  const attr = entry.header && entry.header.attr;
  return typeof attr === 'number' && ((attr >>> 16) & 0o170000) === 0o120000;
}

function hasOwn(obj, key) {
  return obj !== null && typeof obj === 'object' && Object.prototype.hasOwnProperty.call(obj, key);
}

function validateManifest(m) {
  const e = [];
  if (m === null || typeof m !== 'object' || Array.isArray(m)) return ['MANIFEST_NOT_OBJECT'];
  if (m.schema !== SCHEMA) e.push('SCHEMA_MISMATCH');
  if (typeof m.id !== 'string' || !ID_RE.test(m.id)) e.push('ID_INVALID');
  if (typeof m.name !== 'string' || m.name.trim().length === 0 || m.name.length > 80) e.push('NAME_INVALID');
  if (typeof m.version !== 'string' || m.version.length === 0 || m.version.length > 40) e.push('VERSION_INVALID');
  if (m.description !== undefined && (typeof m.description !== 'string' || m.description.length > 500)) {
    e.push('DESCRIPTION_INVALID');
  }
  if (!SUPPORTED_RUNTIMES.includes(m.runtime)) e.push('RUNTIME_NOT_SUPPORTED');
  if (m.autoStart === true || m.bootCritical === true) e.push('THIRD_PARTY_FLAG_FORBIDDEN');
  if (m.capabilities !== undefined) {
    if (!Array.isArray(m.capabilities)) {
      e.push('CAPABILITY_INVALID');
    } else {
      for (const c of m.capabilities) if (!KNOWN_CAPABILITIES.includes(c)) e.push('CAPABILITY_UNKNOWN');
      if (new Set(m.capabilities).size !== m.capabilities.length) e.push('CAPABILITY_DUPLICATE');
    }
  }
  if (m.files === null || typeof m.files !== 'object' || Array.isArray(m.files) || Object.keys(m.files).length === 0) {
    e.push('FILES_INVALID');
  } else {
    if (Object.keys(m.files).length > LIMITS.maxEntries - 1) e.push('TOO_MANY_ENTRIES');
    const lower = Object.keys(m.files).map((k) => k.toLowerCase());
    if (new Set(lower).size !== lower.length) e.push('CASE_COLLISION');
    for (const [rel, sha] of Object.entries(m.files)) {
      if (!isSafeRelPath(rel)) e.push('UNSAFE_PATH');
      if (typeof sha !== 'string' || !SHA_RE.test(sha)) e.push('HASH_FORMAT_INVALID');
    }
  }
  const entryOk =
    typeof m.entry === 'string' &&
    /^web\/.+\.html$/.test(m.entry) &&
    isSafeRelPath(m.entry) &&
    hasOwn(m.files, m.entry);
  if (!entryOk) e.push('ENTRY_INVALID');
  return [...new Set(e)];
}

function reject(errors) {
  return { ok: false, errors: [...new Set(errors)], manifest: null, files: null };
}

// Returns { ok, errors, manifest, files } where files is Map<relPath, Buffer>.
// Nothing is written; the caller installs only when ok is true.
function verifyCartridgeZip(buf) {
  let zip;
  try {
    zip = new AdmZip(buf);
  } catch {
    return reject(['ZIP_UNREADABLE']);
  }
  const all = zip.getEntries();
  if (all.length > LIMITS.maxEntries) return reject(['TOO_MANY_ENTRIES']);
  const files = all.filter((x) => !x.isDirectory);
  if (files.some(isSymlink)) return reject(['SYMLINK_FORBIDDEN']);

  const manifests = files.filter((x) => x.entryName === 'manifest.json' || /\/manifest\.json$/.test(x.entryName));
  if (manifests.length !== 1) return reject(['MANIFEST_COUNT_NOT_ONE']);
  const mEntry = manifests[0];
  if (mEntry.header.size > LIMITS.maxManifestBytes) return reject(['MANIFEST_TOO_LARGE']);

  let manifest;
  try {
    manifest = JSON.parse(mEntry.getData().toString('utf8'));
  } catch {
    return reject(['MANIFEST_NOT_JSON']);
  }
  const manifestErrors = validateManifest(manifest);
  if (manifestErrors.length) return reject(manifestErrors);

  // The manifest sits at the ZIP root, or under one wrapper directory named after its id.
  const prefix = mEntry.entryName.slice(0, mEntry.entryName.length - 'manifest.json'.length);
  if (prefix !== '' && prefix !== `${manifest.id}/`) return reject(['WRAPPER_MISMATCH']);

  let total = 0;
  for (const x of files) {
    if (!x.entryName.startsWith(prefix)) return reject(['STRAY_ENTRY']);
    if (x.header.size > LIMITS.maxFileBytes) return reject(['FILE_TOO_LARGE']);
    total += x.header.size;
    if (total > LIMITS.maxTotalBytes) return reject(['TOTAL_TOO_LARGE']);
  }

  const byRel = new Map();
  for (const x of files) {
    if (x === mEntry) continue;
    const rel = x.entryName.slice(prefix.length);
    if (!isSafeRelPath(rel)) return reject(['UNSAFE_PATH']);
    if (byRel.has(rel)) return reject(['DUPLICATE_ENTRY']);
    byRel.set(rel, x);
  }
  for (const rel of Object.keys(manifest.files)) {
    if (!byRel.has(rel)) return reject(['MISSING_FILE']);
  }

  const out = new Map();
  for (const [rel, x] of byRel) {
    if (!hasOwn(manifest.files, rel)) return reject(['UNLISTED_FILE']);
    let data;
    try {
      data = x.getData();
    } catch {
      return reject(['READ_ERROR']);
    }
    if (sha256Hex(data) !== manifest.files[rel]) return reject(['HASH_MISMATCH']);
    out.set(rel, data);
  }

  return {
    ok: true,
    errors: [],
    manifest: { ...manifest, capabilities: manifest.capabilities || [] },
    files: out,
  };
}

module.exports = { verifyCartridgeZip, validateManifest, isSafeRelPath, sha256Hex, ID_RE, LIMITS };
