# Installs the local voice pack (Piper voice + Whisper tiny) into %APPDATA%\B.Link\speech.
# Safe to run again: finished pieces are skipped. Every download is size and SHA-256 checked before use.
param([string]$Pack, [string]$Dest, [string]$Work)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
function Say($m) { Write-Host ("voicepack: " + $m) }
$spec = Get-Content -Raw -Path $Pack | ConvertFrom-Json
New-Item -ItemType Directory -Force -Path $Dest, $Work | Out-Null
$failed = 0
foreach ($a in $spec.assets) {
  try {
    $target = Join-Path $Dest $a.dest
    $marker = Join-Path $target '.ok'
    if ((Test-Path $marker) -and ((Get-Content -Raw $marker).Trim() -eq $a.sha256)) { Say "$($a.id): already installed"; continue }
    $file = Join-Path $Work ($a.id + '.tar.bz2')
    $ok = $false
    if (Test-Path $file) { $ok = ((Get-FileHash $file -Algorithm SHA256).Hash.ToLower() -eq $a.sha256) }
    if (-not $ok) {
      Say "$($a.id): downloading ($([math]::Round($a.bytes / 1MB)) MB)"
      Invoke-WebRequest -Uri $a.url -OutFile $file -UseBasicParsing
    }
    $hash = (Get-FileHash $file -Algorithm SHA256).Hash.ToLower()
    if ($hash -ne $a.sha256) { Remove-Item $file -Force; throw "checksum mismatch for $($a.id): got $hash" }
    $ex = Join-Path $Work ($a.id + '-x')
    Remove-Item $ex -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $ex | Out-Null
    & tar.exe -xjf $file -C $ex
    if ($LASTEXITCODE -ne 0) { throw "tar could not unpack $($a.id)" }
    $src = Join-Path $ex $a.folder
    Remove-Item $target -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    foreach ($n in $a.copy) {
      $from = Join-Path $src $n
      if (-not (Test-Path $from)) { throw "missing $n in $($a.id)" }
      Copy-Item -Path $from -Destination $target -Recurse -Force
    }
    Set-Content -Path $marker -Value $a.sha256
    Remove-Item $ex -Recurse -Force -ErrorAction SilentlyContinue
    Say "$($a.id): installed"
  } catch {
    $failed++
    Say "$($a.id): FAILED $($_.Exception.Message)"
  }
}
if ($failed -eq 0) { Say 'voice pack ready' } else { Say "voice pack incomplete ($failed failed); B.Link still works without it" }
