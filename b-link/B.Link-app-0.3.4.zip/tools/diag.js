'use strict';
// B.Link diagnostics for the return zip. Read-only. Never prints keys, passphrase hashes or encrypted blobs.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const data = process.env.B_LINK_DATA || path.join(process.env.APPDATA || path.join(require('os').homedir(), '.config'), 'B.Link');
const out = { app: {}, seed: [], data: { dir: data }, installed: [], settings: null, audit: [] };
const rd = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch { return null; } };
const js = (p) => { try { return JSON.parse(rd(p)); } catch { return null; } };

const pkg = js(path.join(root, 'package.json')) || {};
out.app = { version: pkg.version, node: process.version, platform: process.platform, arch: process.arch };

const { verifyCartridgeZip } = require(path.join(root, 'src/cartridge/verify.js'));
const seedDir = path.join(root, 'seed');
for (const f of (fs.existsSync(seedDir) ? fs.readdirSync(seedDir) : []).filter((x) => x.endsWith('.zip'))) {
  const v = verifyCartridgeZip(fs.readFileSync(path.join(seedDir, f)));
  out.seed.push({ file: f, ok: v.ok, id: v.manifest && v.manifest.id, version: v.manifest && v.manifest.version, errors: v.errors });
}

out.data.exists = fs.existsSync(data);
out.data.files = out.data.exists ? fs.readdirSync(data).sort() : [];
out.data.adminConfigured = fs.existsSync(path.join(data, 'admin.json'));
const cdir = path.join(data, 'cartridges');
const grants = js(path.join(data, 'grants.json')) || {};
for (const id of (fs.existsSync(cdir) ? fs.readdirSync(cdir) : []).filter((x) => !x.startsWith('.'))) {
  const m = js(path.join(cdir, id, 'manifest.json')) || {};
  out.installed.push({ id, version: m.version, capabilities: m.capabilities || [], granted: grants[id] || [] });
}
const sdir = path.join(data, 'speech');
const ls = (d) => { try { return fs.readdirSync(d).sort(); } catch { return null; } };
out.speech = { dir: sdir, voices: ls(path.join(sdir, 'voices')), whisperFiles: ls(path.join(sdir, 'whisper')) };
const s = js(path.join(data, 'settings.json'));
if (s) {
  out.settings = {
    killSwitch: !!s.killSwitch,
    disabled: s.disabled || [],
    embeds: s.embeds || {},
    speech: s.speech || null,
    providers: Object.fromEntries(Object.entries(s.providers || {}).map(([k, v]) => [k, { model: v.model || null, keyStored: !!v.keyEnc }])),
  };
}
out.audit = (rd(path.join(data, 'audit.jsonl')) || '').split('\n').filter(Boolean).slice(-60);
console.log(JSON.stringify(out, null, 2));
