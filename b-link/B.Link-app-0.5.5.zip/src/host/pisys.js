'use strict';
// Raspberry Pi OS settings: clock and Bluetooth. Everything privileged goes through one root helper
// (/usr/local/sbin/blink-sys, installed by the B.Link OS system update) that only knows a fixed list of commands.
const { execFile } = require('node:child_process');
const fs = require('node:fs');

const HELPER = '/usr/local/sbin/blink-sys';
const CMDS = new Set(['time-status', 'tz-set', 'ntp-sync', 'time-set', 'bt-scan', 'bt-list', 'bt-pair', 'bt-connect', 'bt-disconnect', 'bt-remove']);
const SLOW = { 'bt-scan': 25000, 'bt-pair': 40000, 'bt-connect': 25000 };

const available = () => process.platform === 'linux' && fs.existsSync(HELPER);

function sys(cmd, arg = '', helper = HELPER, sudo = 'sudo') {
  if (!CMDS.has(cmd)) return Promise.resolve({ ok: false, out: 'UNKNOWN_COMMAND' });
  const args = ['-n', helper, cmd]; if (arg) args.push(String(arg));
  return new Promise((resolve) => execFile(sudo, args, { timeout: SLOW[cmd] || 12000, encoding: 'utf8' }, (e, out, err) => resolve({ ok: !e, out: `${out || ''}${e ? err || '' : ''}`.trim() })));
}

function parseStatus(text) {
  const g = (k) => ((text.match(new RegExp(`^${k}=(.*)$`, 'm')) || [])[1] || '').trim();
  return { timezone: g('Timezone'), ntp: g('NTP') === 'yes', synced: g('NTPSynchronized') === 'yes', local: g('LOCAL') };
}
function parseDevices(text) {
  return text.split('\n').filter((l) => l.startsWith('DEV|')).map((l) => { const [, mac, name, paired, connected] = l.split('|'); return { mac, name, paired: paired === 'yes', connected: connected === 'yes' }; });
}

// Headset microphone needs the call profile; music-only quality needs the other one.
function setBtProfile(mode, env = process.env) {
  const e = { ...env, XDG_RUNTIME_DIR: env.XDG_RUNTIME_DIR || `/run/user/${process.getuid()}` };
  const pa = (args) => new Promise((resolve) => execFile('pactl', args, { env: e, timeout: 6000, encoding: 'utf8' }, (er, out) => resolve({ ok: !er, out: out || '' })));
  return (async () => {
    const cards = await pa(['list', 'cards', 'short']);
    const card = (cards.out.split('\n').map((l) => l.split('\t')[1]).find((n) => n && n.startsWith('bluez_card')));
    if (!card) return { ok: false, out: 'NO_BLUETOOTH_AUDIO_DEVICE' };
    const tries = mode === 'mic' ? ['headset-head-unit', 'headset-head-unit-msbc', 'headset-head-unit-cvsd'] : ['a2dp-sink', 'a2dp-sink-sbc'];
    for (const p of tries) { const r = await pa(['set-card-profile', card, p]); if (r.ok) return { ok: true, out: p }; }
    return { ok: false, out: 'PROFILE_NOT_AVAILABLE' };
  })();
}

module.exports = { available, sys, parseStatus, parseDevices, setBtProfile, CMDS, HELPER };
