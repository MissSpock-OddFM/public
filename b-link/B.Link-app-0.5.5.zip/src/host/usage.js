'use strict';
// API usage meter. Records tokens and cost for every AI call (never any message text).
// xAI reports the exact charge in the response, so those dollars are exact. For OpenAI the dollars are
// an estimate from published per-million-token prices (editable by the administrator).
const fs = require('node:fs');
const path = require('node:path');

// USD per 1M tokens, [input, output]. From OpenAI's published price list, November 2026. Edit under ADMIN > USAGE.
const OPENAI_PRICES = Object.freeze({
  'gpt-6.2-astra': [8, 40], 'gpt-6.2-sol': [2, 10], 'gpt-6-astra': [10, 50], 'gpt-6.1-sol': [2, 10],
  'gpt-6.1-terra': [1, 5], 'gpt-6-luna': [0.1, 0.5], 'gpt-6-sol': [2, 10], 'gpt-5.6-sol': [4, 20],
  'gpt-5.6-terra': [2, 12], 'gpt-5.6-luna': [0.2, 1.2], 'gpt-5.5': [5, 30], 'gpt-5.5-pro': [30, 180],
  'gpt-5.4': [2.5, 15], 'gpt-5.4-pro': [30, 180],
});
const TICKS_PER_USD = 1e10;
const DAY_LIMITS = Object.freeze([0, 1, 2, 5, 10, 20, 50]); // 0 = no limit

function priceFor(provider, model, overrides = {}) {
  const o = overrides[provider];
  if (o && Number(o.in) >= 0 && Number(o.out) >= 0 && (Number(o.in) > 0 || Number(o.out) > 0)) return [Number(o.in), Number(o.out)];
  if (provider !== 'openai' || typeof model !== 'string') return null;
  const id = model.replace(/-\d{4}-\d{2}-\d{2}$/, '');
  return OPENAI_PRICES[id] || null;
}

class Usage {
  constructor(root, { now = () => Date.now(), getOverrides = () => ({}) } = {}) {
    this.file = path.join(root, 'usage.jsonl');
    this.now = now;
    this.getOverrides = getOverrides;
    this.rows = [];
    try {
      for (const line of fs.readFileSync(this.file, 'utf8').split('\n').slice(-200000)) {
        if (!line) continue;
        try { this.rows.push(JSON.parse(line)); } catch { /* skip a damaged line */ }
      }
    } catch { /* no file yet */ }
  }

  // costUsd: exact dollars reported by the provider, if any.
  record({ provider, model, input = 0, output = 0, cached = 0, costUsd = null, src = 'cartridge' }) {
    const inTok = Math.max(0, Math.round(Number(input) || 0));
    const outTok = Math.max(0, Math.round(Number(output) || 0));
    let usd = null;
    let exact = false;
    if (Number.isFinite(costUsd) && costUsd >= 0) { usd = costUsd; exact = true; }
    else {
      const p = priceFor(provider, model, this.getOverrides());
      if (p) usd = (inTok * p[0] + outTok * p[1]) / 1e6;
    }
    const row = { t: this.now(), provider: String(provider), model: String(model || '').slice(0, 80), in: inTok, out: outTok, cached: Math.max(0, Math.round(Number(cached) || 0)), usd, exact, src: String(src).slice(0, 12) };
    this.rows.push(row);
    try { fs.appendFileSync(this.file, JSON.stringify(row) + '\n', { mode: 0o600 }); } catch { /* the meter must never break a call */ }
    return row;
  }

  _sum(pred) {
    const by = {};
    for (const r of this.rows) {
      if (!pred(r)) continue;
      const a = (by[r.provider] ||= { calls: 0, in: 0, out: 0, usd: 0, unpriced: 0, estimated: 0 });
      a.calls += 1; a.in += r.in; a.out += r.out;
      if (r.usd === null) a.unpriced += 1; else { a.usd += r.usd; if (!r.exact) a.estimated += 1; }
    }
    return by;
  }

  summary() {
    const d = new Date(this.now());
    const day = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const month = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
    return { today: this._sum((r) => r.t >= day), month: this._sum((r) => r.t >= month), all: this._sum(() => true), dayLimits: DAY_LIMITS };
  }

  todayUsd() {
    const t = this.summary().today;
    return Object.values(t).reduce((s, a) => s + a.usd, 0);
  }
}

module.exports = { Usage, priceFor, OPENAI_PRICES, DAY_LIMITS, TICKS_PER_USD };
