'use strict';
// Gives cartridges built to the native C.Link standard (kit 005, BRIDGE_CLIENT/clink-native.js) the
// window.clinkCartridgeLLM object they look for. It only forwards to the same host bridge every cartridge
// already uses (postMessage to the B.Link shell), so keys, consent, budget and the kill switch all still apply.
const SHIM = `(function(){'use strict';
var n=0,pend={};
window.addEventListener('message',function(e){var d=e.data;if(e.source!==window.parent||!d||d.clink!==1||d.type!=='res')return;var s=pend[d.id];if(!s)return;clearTimeout(s.t);delete pend[d.id];s.r(d);});
function call(op,args,ms){return new Promise(function(r){var id='nb-'+Date.now()+'-'+(++n);var t=setTimeout(function(){delete pend[id];r({ok:false,error:'HOST_BRIDGE_TIMEOUT_OR_UNAVAILABLE'});},ms||50000);pend[id]={r:r,t:t};window.parent.postMessage({clink:1,type:'req',id:id,op:op,args:args},'*');});}
function err(d){var e=d.error;return typeof e==='string'?e:(e&&e.code)||'CLINK_NATIVE_ERROR';}
Object.defineProperty(window,'clinkCartridgeLLM',{value:Object.freeze({
 status:async function(){var d=await call('bridge.providers',{},3500);return d.ok?{ok:true,providers:(d.result&&d.result.providers)||[]}:{ok:false,error:err(d)};},
 generate:async function(a){var d=await call('bridge.chat',{provider:a.provider,requestId:'g'+Date.now().toString(36)+(++n),messages:[{role:'user',content:a.prompt}]});
  return d.ok?{ok:true,text:d.result.text,provider:d.result.provider,usage:d.result.usage}:{ok:false,error:err(d)};}
}),configurable:false});
})();`;
const SHIM_PATH = '/__blink/clink-native-shim.js';
const TAG = `<script src="${SHIM_PATH}"></script>`;
function injectShim(html) {
  const s = String(html);
  const m = /<head[^>]*>/i.exec(s);
  return m ? s.slice(0, m.index + m[0].length) + TAG + s.slice(m.index + m[0].length) : TAG + s;
}
module.exports = { SHIM, SHIM_PATH, injectShim };
