'use strict';
// Host settings: kill switch, per-cartridge disable flags, and provider models and keys.
// Keys are encrypted with an injected function (Electron safeStorage in the app) and are
// never returned to the UI; status() reports only whether a key is stored.
const fs = require('node:fs');
const path = require('node:path');
const { EMBED_PRESETS } = require('./csp');

const PROVIDERS = Object.freeze(['openai', 'xai']);
const VOICE_RE = /^[A-Za-z0-9_-]{3,60}$/;
const DEFAULT_VOICE = 'en_US-kathleen-low';
const MODEL_RE = /^[A-Za-z0-9._:-]{1,100}$/;
const ok = () => ({ ok: true, errors: [] });
const fail = (...errors) => ({ ok: false, errors });

class Settings {
  constructor(root, { encrypt, decrypt }) {
    this.file = path.join(root, 'settings.json');
    this.encrypt = encrypt;
    this.decrypt = decrypt;
  }

  _read() {
    try {
      const s = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      return s && typeof s === 'object' && !Array.isArray(s) ? s : {};
    } catch {
      return {};
    }
  }

  _write(s) {
    fs.writeFileSync(this.file, JSON.stringify(s, null, 2), { mode: 0o600 });
  }

  killSwitch() {
    return this._read().killSwitch === true;
  }

  setKillSwitch(on) {
    const s = this._read();
    s.killSwitch = on === true;
    this._write(s);
    return ok();
  }

  isDisabled(id) {
    const d = this._read().disabled;
    return !!(d && d[id] === true);
  }

  setDisabled(id, disabled) {
    const s = this._read();
    s.disabled = s.disabled || {};
    if (disabled) s.disabled[id] = true;
    else delete s.disabled[id];
    this._write(s);
    return ok();
  }

  forget(id) {
    const s = this._read();
    if (s.disabled) delete s.disabled[id];
    if (s.embeds) delete s.embeds[id];
    this._write(s);
    return ok();
  }

  // null means no admin has decided yet; an empty list means the admin chose "no embeds".
  getEmbeds(id) {
    const e = this._read().embeds;
    return e && Object.hasOwn(e, id) && Array.isArray(e[id]) ? e[id] : null;
  }

  setEmbeds(id, list) {
    if (!Array.isArray(list) || !list.every((x) => typeof x === 'string' && Object.hasOwn(EMBED_PRESETS, x))) {
      return fail('EMBED_UNKNOWN');
    }
    const s = this._read();
    s.embeds = s.embeds || {};
    s.embeds[id] = [...new Set(list)];
    this._write(s);
    return ok();
  }

  setProvider(name, { model, apiKey } = {}) {
    if (!PROVIDERS.includes(name)) return fail('PROVIDER_UNSUPPORTED');
    const s = this._read();
    s.providers = s.providers || {};
    const cur = s.providers[name] || {};
    if (model !== undefined) {
      if (model === null || model === '') delete cur.model; // back to automatic
      else {
        if (typeof model !== 'string' || !MODEL_RE.test(model)) return fail('MODEL_INVALID');
        cur.model = model;
      }
    }
    if (apiKey !== undefined) {
      if (apiKey === null || apiKey === '') {
        delete cur.keyEnc;
      } else {
        if (typeof apiKey !== 'string' || apiKey.length > 400) return fail('KEY_INVALID');
        try {
          cur.keyEnc = this.encrypt(apiKey).toString('base64');
        } catch {
          return fail('ENCRYPTION_UNAVAILABLE');
        }
      }
    }
    s.providers[name] = cur;
    this._write(s);
    return ok();
  }

  getKey(name) {
    const c = (this._read().providers || {})[name];
    if (!c || !c.keyEnc) return null;
    try {
      return this.decrypt(Buffer.from(c.keyEnc, 'base64'));
    } catch {
      return null;
    }
  }

  getModel(name) {
    const c = (this._read().providers || {})[name];
    return (c && c.model) || null;
  }

  // Voice preferences. Defaults apply until an administrator changes them.
  getSpeech() {
    const s = this._read().speech || {};
    const speed = Number(s.speed);
    return {
      voice: typeof s.voice === 'string' && VOICE_RE.test(s.voice) ? s.voice : DEFAULT_VOICE,
      readAloud: s.readAloud !== false,
      speed: speed >= 0.6 && speed <= 1.6 ? speed : 1.0,
    };
  }

  setSpeech(patch = {}) {
    const cur = this.getSpeech();
    if (patch.voice !== undefined) {
      if (typeof patch.voice !== 'string' || !VOICE_RE.test(patch.voice)) return fail('VOICE_INVALID');
      cur.voice = patch.voice;
    }
    if (patch.readAloud !== undefined) cur.readAloud = patch.readAloud === true;
    if (patch.speed !== undefined) {
      const sp = Number(patch.speed);
      if (!(sp >= 0.6 && sp <= 1.6)) return fail('SPEED_INVALID');
      cur.speed = Math.round(sp * 100) / 100;
    }
    const s = this._read();
    s.speech = cur;
    this._write(s);
    return ok();
  }

  // Daily spending limit in dollars (0 = none) and optional per-million-token price overrides.
  getBudget() {
    const s = this._read();
    const lim = Number(s.dailyLimitUsd);
    const pr = s.priceOverrides && typeof s.priceOverrides === 'object' ? s.priceOverrides : {};
    const clean = {};
    for (const p of PROVIDERS) {
      const o = pr[p];
      if (o && Number(o.in) >= 0 && Number(o.out) >= 0) clean[p] = { in: Number(o.in), out: Number(o.out) };
    }
    return { dailyLimitUsd: [0, 1, 2, 5, 10, 20, 50].includes(lim) ? lim : 0, priceOverrides: clean };
  }

  setBudget(patch = {}) {
    const s = this._read();
    if (patch.dailyLimitUsd !== undefined) {
      const n = Number(patch.dailyLimitUsd);
      if (![0, 1, 2, 5, 10, 20, 50].includes(n)) return fail('LIMIT_INVALID');
      s.dailyLimitUsd = n;
    }
    if (patch.price !== undefined) {
      const q = patch.price || {};
      if (!PROVIDERS.includes(q.provider)) return fail('PROVIDER_UNSUPPORTED');
      const i = Number(q.in), o = Number(q.out);
      if (!(i >= 0 && i <= 1000 && o >= 0 && o <= 1000)) return fail('PRICE_INVALID');
      s.priceOverrides = { ...(s.priceOverrides || {}), [q.provider]: { in: i, out: o } };
    }
    this._write(s);
    return ok();
  }

  // Accept updates pushed from a paired controller. On by default on Linux (the Raspberry Pi), off elsewhere.
  getDeviceLink() {
    const v = this._read().deviceLink;
    return typeof v === 'boolean' ? v : process.platform === 'linux';
  }

  setDeviceLink(on) {
    const s = this._read();
    s.deviceLink = on === true;
    this._write(s);
    return ok();
  }

  // Admin auto-lock in minutes. 0 means: stay unlocked until LOCK or until B.Link is closed.
  getLockMinutes() {
    const m = Number(this._read().lockMinutes);
    return [0, 10, 60].includes(m) ? m : 0;
  }

  setLockMinutes(m) {
    const n = Number(m);
    if (![0, 10, 60].includes(n)) return fail('LOCK_INVALID');
    const s = this._read();
    s.lockMinutes = n;
    this._write(s);
    return ok();
  }

  status() {
    const providers = this._read().providers || {};
    return {
      killSwitch: this.killSwitch(),
      speech: this.getSpeech(),
      lockMinutes: this.getLockMinutes(),
      budget: this.getBudget(),
      providers: Object.fromEntries(
        PROVIDERS.map((p) => [p, { configured: !!(providers[p] && providers[p].keyEnc), model: (providers[p] && providers[p].model) || null }]),
      ),
    };
  }
}

module.exports = { Settings, PROVIDERS, DEFAULT_VOICE };
