'use strict';
// Updates B.Link's own app folder without any launcher: download, verify SHA-256, unpack beside the live
// folder, then a tiny script swaps it in after B.Link quits and starts B.Link again. If the swap fails the
// old folder is put back. Only used when Electron itself is unchanged (otherwise Setup is needed).
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

// install.json is PascalCase from the Windows installer and lowercase from the Pi installer; keep whichever style it has.
function writeInstNew(installDir, version, appSha, extra = {}) {
  const inst = readInstalled(installDir) || {};
  const pascal = 'Version' in inst || !('version' in inst);
  const next = pascal ? { ...inst, Version: version, AppSHA: appSha } : { ...inst, version, app: appSha };
  delete next.pushed;
  fs.writeFileSync(path.join(installDir, 'install.json.new'), JSON.stringify({ ...next, ...extra }));
}

function readInstalled(installDir) {
  try { return JSON.parse(fs.readFileSync(path.join(installDir, 'install.json'), 'utf8')); } catch { return null; }
}

// Can this running copy update itself? Needs the Setup-made layout and an unchanged Electron.
function canSelfUpdate({ appDir, installDir, manifest, platform = process.platform }) {
  if (platform !== 'win32') return false;
  if (path.basename(appDir) !== 'app' || path.basename(path.dirname(appDir)) !== 'resources') return false;
  const inst = readInstalled(installDir);
  return !!(inst && manifest && manifest.electron && inst.ElectronSHA && inst.ElectronSHA === manifest.electron.sha256);
}

function extractSafe(zipBuf, dest) {
  const AdmZip = require('adm-zip');
  const zip = new AdmZip(zipBuf);
  const root = path.resolve(dest);
  fs.mkdirSync(root, { recursive: true });
  for (const e of zip.getEntries()) {
    const target = path.resolve(root, e.entryName);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error('UNSAFE_PATH');
    if (e.isDirectory) { fs.mkdirSync(target, { recursive: true }); continue; }
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, e.getData());
  }
}

// Downloads and unpacks into <appDir>.new and writes install.json.new. Throws on any problem; the live app is untouched.
async function stage({ manifest, baseUrl, appDir, installDir, fetchFn = globalThis.fetch }) {
  const a = manifest.app;
  if (!a || !a.url || !/^[0-9a-f]{64}$/i.test(a.sha256 || '')) throw new Error('BAD_MANIFEST');
  const url = /^https:\/\//.test(a.url) ? a.url : new URL(a.url, baseUrl).toString();
  const res = await fetchFn(url, { signal: AbortSignal.timeout(120000) });
  if (!res.ok) throw new Error(`HTTP_${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (sha256(buf) !== a.sha256.toLowerCase()) throw new Error('CHECKSUM_MISMATCH');
  const fresh = `${appDir}.new`;
  fs.rmSync(fresh, { recursive: true, force: true });
  try { extractSafe(buf, fresh); } catch (e) { fs.rmSync(fresh, { recursive: true, force: true }); throw e; }
  if (!fs.existsSync(path.join(fresh, 'package.json')) || !fs.existsSync(path.join(fresh, 'src', 'main.js'))) {
    fs.rmSync(fresh, { recursive: true, force: true });
    throw new Error('BAD_PACKAGE');
  }
  writeInstNew(installDir, manifest.version, a.sha256);
  return { fresh };
}

// The swap script: waits for B.Link to exit, swaps with rollback, then starts B.Link.
function swapScript({ appDir, installDir, exe }) {
  const q = (s) => `"${s}"`;
  const old = `${appDir}.old`;
  return [
    '@echo off',
    'set n=0',
    ':wait',
    'ping -n 2 127.0.0.1 >nul',
    `if exist ${q(old)} rd /s /q ${q(old)} 2>nul`,
    `move ${q(appDir)} ${q(old)} >nul 2>nul`,
    `if not exist ${q(appDir)} goto swapped`,
    'set /a n+=1',
    'if %n% lss 30 goto wait',
    'goto launch',
    ':swapped',
    `move ${q(`${appDir}.new`)} ${q(appDir)} >nul 2>nul`,
    `if exist ${q(appDir)} goto done`,
    `move ${q(old)} ${q(appDir)} >nul 2>nul`,
    'goto launch',
    ':done',
    `move /y ${q(path.join(installDir, 'install.json.new'))} ${q(path.join(installDir, 'install.json'))} >nul 2>nul`,
    ':launch',
    `start "" ${q(exe)}`,
    'del "%~f0" & exit',
    '',
  ].join('\r\n');
}

// A pushed update is a small overlay (src, renderer, package.json...) applied over a copy of the live app,
// so node_modules (including the right speech engine for this machine) is kept.
function stageOverlay({ appDir, installDir, zip, version }) {
  const fresh = `${appDir}.new`;
  fs.rmSync(fresh, { recursive: true, force: true });
  fs.cpSync(appDir, fresh, { recursive: true, verbatimSymlinks: true });
  try { extractSafe(zip, fresh); } catch (e) { fs.rmSync(fresh, { recursive: true, force: true }); throw e; }
  let pj = null; try { pj = JSON.parse(fs.readFileSync(path.join(fresh, 'package.json'), 'utf8')); } catch { /* checked below */ }
  if (!pj || typeof pj.version !== 'string' || !fs.existsSync(path.join(fresh, 'src', 'main.js'))) {
    fs.rmSync(fresh, { recursive: true, force: true });
    throw new Error('BAD_PACKAGE');
  }
  writeInstNew(installDir, pj.version, `pushed:${pj.version}`, { pushed: pj.version });
  return pj.version;
}

// Shell version of the swap, for the Raspberry Pi. When systemd runs B.Link (the kiosk), it restarts it by itself.
function swapScriptSh({ appDir, installDir, pid, relaunch }) {
  const q = (x) => `'${String(x).replace(/'/g, "'\\''")}'`;
  return [
    '#!/bin/sh',
    'i=0',
    `while kill -0 ${Number(pid)} 2>/dev/null && [ $i -lt 80 ]; do sleep 0.5; i=$((i+1)); done`,
    `rm -rf ${q(`${appDir}.old`)}`,
    `if mv ${q(appDir)} ${q(`${appDir}.old`)}; then`,
    `  if mv ${q(`${appDir}.new`)} ${q(appDir)}; then`,
    `    [ -f ${q(path.join(installDir, 'install.json.new'))} ] && mv -f ${q(path.join(installDir, 'install.json.new'))} ${q(path.join(installDir, 'install.json'))}`,
    '  else',
    `    mv ${q(`${appDir}.old`)} ${q(appDir)}`,
    '  fi',
    'fi',
    relaunch ? `nohup ${q(relaunch)} >/dev/null 2>&1 &` : ':',
    'rm -f "$0"',
    '',
  ].join('\n');
}

// Previous version kept by the last update (<appDir>.old), if it is complete.
function previousVersion(appDir) {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(`${appDir}.old`, 'package.json'), 'utf8'));
    return fs.existsSync(path.join(`${appDir}.old`, 'src', 'main.js')) && typeof j.version === 'string' ? j.version : null;
  } catch { return null; }
}

// Roll back = stage the previous version as if it were an update, then run the same safe swap.
// The version being left becomes <appDir>.old, so it can be rolled forward again.
function stageRollback({ appDir, installDir }) {
  const prev = previousVersion(appDir);
  if (!prev) throw new Error('NO_PREVIOUS');
  fs.rmSync(`${appDir}.new`, { recursive: true, force: true });
  fs.renameSync(`${appDir}.old`, `${appDir}.new`);
  writeInstNew(installDir, prev, 'rolled-back');
  return prev;
}

// Boot health: a version that is started twice without ever reaching a working window is rolled back on the third start.
function bootCheck(file, version) {
  let b = null;
  try { b = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { /* first run */ }
  const failedBefore = b && b.version === version && b.ok === false ? b.tries : 0;
  fs.writeFileSync(file, JSON.stringify({ version, ok: false, tries: failedBefore + 1 }));
  return failedBefore >= 2;
}
function bootOk(file, version) {
  try { fs.writeFileSync(file, JSON.stringify({ version, ok: true, tries: 0 })); } catch { /* ignore */ }
}

module.exports = { stageOverlay, swapScriptSh, writeInstNew, previousVersion, stageRollback, bootCheck, bootOk, canSelfUpdate, stage, swapScript, extractSafe, readInstalled };
