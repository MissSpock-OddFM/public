'use strict';
// Device link: lets a paired B.Link controller (for example B.Link on your Windows PC) send an update to,
// or read diagnostics from, a B.Link device (for example the Raspberry Pi) over the home network.
//  - Pairing: the device shows a one-time 6-digit code; the controller sends it with its public key.
//  - After that every request must be signed (Ed25519) by a paired controller, fresh (2 min) and not replayed.
//  - Only private network addresses are served. Nothing here runs arbitrary commands: the device only
//    accepts an app overlay (checked and swapped in by the host, with rollback) and returns a diagnostics text.
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const PORT = 7733;
const MAX_BODY = 40 * 1024 * 1024;
const SKEW_MS = 120000;
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const canon = (method, p, ts, nonce, bodyHash) => `${method}\n${p}\n${ts}\n${nonce}\n${bodyHash}`;

function isPrivateAddr(a) {
  const s = String(a || '').replace(/^::ffff:/, '');
  return s === '::1' || /^127\./.test(s) || /^10\./.test(s) || /^192\.168\./.test(s) || /^172\.(1[6-9]|2\d|3[01])\./.test(s) || /^169\.254\./.test(s) || /^f[cd][0-9a-f]{2}:/i.test(s) || /^fe80:/i.test(s);
}

function readJson(file, dflt) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return dflt; } }
function writeJson(file, v) { fs.writeFileSync(file, JSON.stringify(v, null, 1), { mode: 0o600 }); }

// ---------------- device side ----------------
class DeviceLink {
  constructor({ dir, name, version, platform, onPush, onDiag, onKeys, onCart, now = Date.now, port = PORT }) {
    Object.assign(this, { dir, name, version, platform, onPush, onDiag, onKeys, onCart, now, port });
    this.xfile = path.join(dir, 'devlink-x.json');
    this.file = path.join(dir, 'devlink.json');
    this.nonces = new Map();
    this.fails = 0; this.lockUntil = 0;
    this.server = null;
    this._newCode();
  }

  _xkey() { // this device's own key for receiving secrets; created once
    let k = readJson(this.xfile, null);
    if (!k || !k.priv) { const kp = crypto.generateKeyPairSync('x25519'); k = { priv: kp.privateKey.export({ type: 'pkcs8', format: 'pem' }) }; writeJson(this.xfile, k); }
    const priv = crypto.createPrivateKey(k.priv);
    return { priv, pub: crypto.createPublicKey(priv).export({ type: 'spki', format: 'der' }).toString('base64') };
  }
  _newCode() { this.code = String(crypto.randomInt(0, 1000000)).padStart(6, '0'); this.codeExp = this.now() + 10 * 60000; }
  currentCode() { if (this.now() > this.codeExp) this._newCode(); return this.code; }
  controllers() { return readJson(this.file, { controllers: [] }).controllers; }
  unpair(id) { const d = readJson(this.file, { controllers: [] }); d.controllers = d.controllers.filter((c) => c.id !== id); writeJson(this.file, d); }

  pair({ code, name, pub }) {
    if (this.now() < this.lockUntil) return { ok: false, error: 'LOCKED' };
    if (typeof code !== 'string' || code !== this.currentCode()) {
      if (++this.fails >= 5) { this.lockUntil = this.now() + 5 * 60000; this.fails = 0; }
      return { ok: false, error: 'BAD_CODE' };
    }
    let key; try { key = crypto.createPublicKey(String(pub)); if (key.asymmetricKeyType !== 'ed25519') throw new Error('type'); } catch { return { ok: false, error: 'BAD_KEY' }; }
    const pem = key.export({ type: 'spki', format: 'pem' });
    const id = sha(pem).slice(0, 16);
    const d = readJson(this.file, { controllers: [] });
    d.controllers = d.controllers.filter((c) => c.id !== id).concat([{ id, name: String(name || 'controller').slice(0, 40), pub: pem, added: new Date(this.now()).toISOString() }]);
    writeJson(this.file, d);
    this.fails = 0; this._newCode();
    return { ok: true, id };
  }

  verify(method, p, headers, body) {
    const id = headers['x-blink-id'], ts = Number(headers['x-blink-ts']), nonce = headers['x-blink-nonce'], sig = headers['x-blink-sig'];
    if (!id || !nonce || !sig || !Number.isFinite(ts)) return 'UNSIGNED';
    if (Math.abs(this.now() - ts) > SKEW_MS) return 'STALE';
    const c = this.controllers().find((x) => x.id === id);
    if (!c) return 'UNKNOWN_CONTROLLER';
    for (const [n, t] of this.nonces) if (this.now() - t > SKEW_MS * 2) this.nonces.delete(n);
    if (this.nonces.has(nonce)) return 'REPLAY';
    let good = false;
    try { good = crypto.verify(null, Buffer.from(canon(method, p, ts, nonce, sha(body))), crypto.createPublicKey(c.pub), Buffer.from(sig, 'base64')); } catch { good = false; }
    if (!good) return 'BAD_SIGNATURE';
    this.nonces.set(nonce, this.now());
    return null;
  }

  async handle(method, p, headers, body, remote) {
    const J = (code, o) => ({ code, type: 'application/json', body: JSON.stringify(o) });
    if (!isPrivateAddr(remote)) return J(403, { ok: false, error: 'LAN_ONLY' });
    if (method === 'GET' && p === '/info') return J(200, { ok: true, app: 'B.Link', name: this.name, version: this.version, platform: this.platform, paired: this.controllers().length > 0, xpub: this._xkey().pub });
    if (method === 'POST' && p === '/pair') { let j; try { j = JSON.parse(body.toString('utf8')); } catch { return J(400, { ok: false, error: 'BAD_JSON' }); } const r = this.pair(j || {}); return J(r.ok ? 200 : 403, r); }
    const bad = this.verify(method, p, headers, body);
    if (bad) return J(401, { ok: false, error: bad });
    if (method === 'GET' && p === '/diag') return { code: 200, type: 'text/plain; charset=utf-8', body: String(await this.onDiag()).slice(0, 200000) };
    if (method === 'POST' && p === '/push') {
      if (headers['x-blink-sha256'] !== sha(body)) return J(400, { ok: false, error: 'CHECKSUM_MISMATCH' });
      const r = await this.onPush(body, { version: String(headers['x-blink-version'] || '') });
      return J(r && r.ok ? 200 : 422, r || { ok: false, error: 'FAILED' });
    }
    if (method === 'POST' && p === '/cart') { // a cartridge (ZIP) plus the sender's permission choices for it
      if (headers['x-blink-sha256'] !== sha(body)) return J(400, { ok: false, error: 'CHECKSUM_MISMATCH' });
      let meta = {}; try { meta = JSON.parse(Buffer.from(String(headers['x-blink-meta'] || ''), 'base64').toString('utf8')); } catch { /* none */ }
      const r = this.onCart ? await this.onCart(body, meta) : { ok: false, error: 'UNSUPPORTED' };
      return J(r && r.ok ? 200 : 422, r || { ok: false, error: 'FAILED' });
    }
    if (method === 'POST' && p === '/keys') { // API keys, encrypted so that only this device can read them
      let plain;
      try {
        const j = JSON.parse(body.toString('utf8'));
        const shared = crypto.diffieHellman({ privateKey: this._xkey().priv, publicKey: crypto.createPublicKey({ key: Buffer.from(j.epub, 'base64'), format: 'der', type: 'spki' }) });
        const k = Buffer.from(crypto.hkdfSync('sha256', shared, Buffer.from('blink-keys-v2'), 'blink-keys', 32));
        const d = crypto.createDecipheriv('aes-256-gcm', k, Buffer.from(j.iv, 'base64')); d.setAuthTag(Buffer.from(j.tag, 'base64'));
        plain = JSON.parse(Buffer.concat([d.update(Buffer.from(j.ct, 'base64')), d.final()]).toString('utf8'));
      } catch { return J(403, { ok: false, error: 'BAD_KEYS_PACKAGE' }); }
      const r = this.onKeys ? await this.onKeys(plain) : { ok: false, error: 'UNSUPPORTED' };
      return J(r && r.ok ? 200 : 422, r || { ok: false, error: 'FAILED' });
    }
    return J(404, { ok: false, error: 'NOT_FOUND' });
  }

  start() {
    this.server = http.createServer((req, res) => {
      const chunks = []; let n = 0; let dead = false;
      req.on('data', (c) => { n += c.length; if (n > MAX_BODY) { dead = true; res.writeHead(413).end(); req.destroy(); } else chunks.push(c); });
      req.on('end', async () => {
        if (dead) return;
        try {
          const u = new URL(req.url, 'http://x');
          const r = await this.handle(req.method, u.pathname, req.headers, Buffer.concat(chunks), req.socket.remoteAddress);
          res.writeHead(r.code, { 'content-type': r.type, 'cache-control': 'no-store' }); res.end(r.body);
        } catch { res.writeHead(500).end(); }
      });
    });
    this.server.on('error', () => {});
    return new Promise((resolve) => this.server.listen(this.port, '0.0.0.0', () => resolve(this.server.address().port)));
  }
  stop() { if (this.server) { this.server.close(); if (this.server.closeAllConnections) this.server.closeAllConnections(); this.server = null; } }
}

// ---------------- controller side ----------------
function loadOrCreateKey(dir) {
  const f = path.join(dir, 'devlink-key.json');
  let k = readJson(f, null);
  if (!k || !k.priv) {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    k = { priv: privateKey.export({ type: 'pkcs8', format: 'pem' }), pub: publicKey.export({ type: 'spki', format: 'pem' }) };
    writeJson(f, k);
  }
  k.id = sha(crypto.createPublicKey(k.pub).export({ type: 'spki', format: 'pem' })).slice(0, 16);
  return k;
}

function request({ host, port = PORT, method, path: p, body = Buffer.alloc(0), key, headers = {}, timeoutMs = 20000 }) {
  return new Promise((resolve) => {
    const h = { ...headers };
    if (key) {
      const ts = Date.now(), nonce = crypto.randomBytes(12).toString('hex');
      h['x-blink-id'] = key.id; h['x-blink-ts'] = String(ts); h['x-blink-nonce'] = nonce;
      h['x-blink-sig'] = crypto.sign(null, Buffer.from(canon(method, p, ts, nonce, sha(body))), crypto.createPrivateKey(key.priv)).toString('base64');
    }
    h['content-length'] = String(body.length);
    const req = http.request({ host, port, method, path: p, headers: h, timeout: timeoutMs }, (res) => {
      const chunks = []; res.on('data', (c) => chunks.push(c));
      res.on('end', () => { const t = Buffer.concat(chunks).toString('utf8'); let j = null; try { j = JSON.parse(t); } catch { /* text */ } resolve({ status: res.statusCode, json: j, text: t }); });
    });
    req.on('timeout', () => { req.destroy(); resolve({ status: 0, error: 'TIMEOUT' }); });
    req.on('error', (e) => resolve({ status: 0, error: String(e.code || e.message).slice(0, 40) }));
    req.end(body);
  });
}

const Controller = {
  info: (host, port) => request({ host, port, method: 'GET', path: '/info', timeoutMs: 1500 }),
  pair: (host, port, code, name, key) => request({ host, port, method: 'POST', path: '/pair', body: Buffer.from(JSON.stringify({ code, name, pub: key.pub })) }),
  diag: (host, port, key) => request({ host, port, method: 'GET', path: '/diag', key }),
  push: (host, port, key, zip, version) => request({ host, port, method: 'POST', path: '/push', body: zip, key, timeoutMs: 120000, headers: { 'x-blink-sha256': sha(zip), 'x-blink-version': version, 'content-type': 'application/zip' } }),
  cart: (host, port, key, zip, meta) => request({ host, port, method: 'POST', path: '/cart', body: zip, key, timeoutMs: 120000, headers: { 'x-blink-sha256': sha(zip), 'x-blink-meta': Buffer.from(JSON.stringify(meta || {})).toString('base64'), 'content-type': 'application/zip' } }),
  async sendKeys(host, port, key, devXpub, payload) {
    const kp = crypto.generateKeyPairSync('x25519');
    const shared = crypto.diffieHellman({ privateKey: kp.privateKey, publicKey: crypto.createPublicKey({ key: Buffer.from(devXpub, 'base64'), format: 'der', type: 'spki' }) });
    const k = Buffer.from(crypto.hkdfSync('sha256', shared, Buffer.from('blink-keys-v2'), 'blink-keys', 32));
    const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', k, iv);
    const ct = Buffer.concat([c.update(Buffer.from(JSON.stringify(payload))), c.final()]);
    const body = Buffer.from(JSON.stringify({ epub: kp.publicKey.export({ type: 'spki', format: 'der' }).toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), ct: ct.toString('base64') }));
    return request({ host, port, method: 'POST', path: '/keys', body, key });
  },
  async scan(prefix, port = PORT) { // prefix like "192.168.1."
    const found = []; const hosts = Array.from({ length: 254 }, (_, i) => `${prefix}${i + 1}`);
    await Promise.all(hosts.map(async (h) => { const r = await Controller.info(h, port); if (r.json && r.json.app === 'B.Link') found.push({ host: h, ...r.json }); }));
    return found;
  },
};

module.exports = { request, DeviceLink, Controller, loadOrCreateKey, isPrivateAddr, PORT, sha };
