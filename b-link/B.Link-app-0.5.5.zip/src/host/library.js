'use strict';
// Host-side cartridge library. Installs only verified packages, serves only SHA-pinned
// files, and keeps capability grants. Grants default to closed.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { verifyCartridgeZip, isSafeRelPath, sha256Hex, ID_RE, LIMITS } = require('../cartridge/verify');

const MIME = Object.freeze({
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
});

function compareVersions(a, b) {
  const pa = String(a).split(/[.+-]/);
  const pb = String(b).split(/[.+-]/);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] ?? '0';
    const y = pb[i] ?? '0';
    if (/^\d+$/.test(x) && /^\d+$/.test(y)) {
      const d = Number(x) - Number(y);
      if (d !== 0) return d < 0 ? -1 : 1;
    } else if (x !== y) {
      return x < y ? -1 : 1;
    }
  }
  return 0;
}

class Library {
  constructor(root, { settings = null } = {}) {
    this.root = root;
    this.settings = settings;
    this.cartridgesDir = path.join(root, 'cartridges');
    this.grantsFile = path.join(root, 'grants.json');
    fs.mkdirSync(this.cartridgesDir, { recursive: true });
  }

  dirFor(id) {
    if (typeof id !== 'string' || !ID_RE.test(id)) throw new Error('ID_INVALID');
    return path.join(this.cartridgesDir, id);
  }

  getManifest(id) {
    if (typeof id !== 'string' || !ID_RE.test(id)) return null;
    try {
      const m = JSON.parse(fs.readFileSync(path.join(this.dirFor(id), 'manifest.json'), 'utf8'));
      return m && m.id === id ? m : null;
    } catch {
      return null;
    }
  }

  listInstalled() {
    const grants = this.readGrants();
    const out = [];
    for (const id of fs.readdirSync(this.cartridgesDir)) {
      const m = this.getManifest(id);
      if (!m) continue;
      const caps = m.capabilities || [];
      out.push({
        id,
        name: m.name,
        version: m.version,
        description: m.description || '',
        entry: m.entry,
        capabilities: caps,
        enabled: this.isEnabled(id),
        hasBackup: this.hasBackup(id),
        embeds: this.settings ? this.settings.getEmbeds(id) || [] : [],
        granted: Object.fromEntries(caps.map((c) => [c, !!(grants[id] && grants[id][c] === true)])),
      });
    }
    return out.sort((a, b) => a.name.localeCompare(b.name));
  }

  // Same-ID updates need the host's signed release channel, which this build does not have.
  installFromZip(buf) {
    if (buf.length > LIMITS.maxTotalBytes) return { ok: false, errors: ['ZIP_TOO_LARGE'] };
    const v = verifyCartridgeZip(buf);
    if (!v.ok) return { ok: false, errors: v.errors };
    const id = v.manifest.id;
    const dest = this.dirFor(id);
    if (fs.existsSync(dest)) return { ok: false, errors: ['ALREADY_INSTALLED'] };
    const tmp = path.join(this.cartridgesDir, `.tmp-${id}-${crypto.randomBytes(6).toString('hex')}`);
    try {
      const tmpRoot = path.resolve(tmp);
      for (const [rel, data] of v.files) {
        const abs = path.resolve(tmpRoot, rel);
        if (!abs.startsWith(tmpRoot + path.sep)) throw new Error('UNSAFE_PATH');
        fs.mkdirSync(path.dirname(abs), { recursive: true });
        fs.writeFileSync(abs, data, { flag: 'wx' });
      }
      fs.writeFileSync(path.join(tmpRoot, 'manifest.json'), JSON.stringify(v.manifest, null, 2));
      fs.renameSync(tmpRoot, dest);
    } catch {
      fs.rmSync(tmp, { recursive: true, force: true });
      return { ok: false, errors: ['INSTALL_FAILED'] };
    }
    return { ok: true, errors: [], id };
  }

  _writeTree(tmp, v) {
    const tmpRoot = path.resolve(tmp);
    for (const [rel, data] of v.files) {
      const abs = path.resolve(tmpRoot, rel);
      if (!abs.startsWith(tmpRoot + path.sep)) throw new Error('UNSAFE_PATH');
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, data, { flag: 'wx' });
    }
    fs.writeFileSync(path.join(tmpRoot, 'manifest.json'), JSON.stringify(v.manifest, null, 2));
    return tmpRoot;
  }

  // Same-ID update: the new ZIP must verify and carry a strictly higher version. The previous version
  // is kept for one rollback. Saves live in the browser profile keyed by cartridge id, so they are
  // untouched. Grants carry over only for capabilities the new version still declares; newly
  // requested capabilities start closed.
  updateFromZip(buf) {
    if (buf.length > LIMITS.maxTotalBytes) return { ok: false, errors: ['ZIP_TOO_LARGE'] };
    const v = verifyCartridgeZip(buf);
    if (!v.ok) return { ok: false, errors: v.errors };
    const id = v.manifest.id;
    const cur = this.getManifest(id);
    if (!cur) return { ok: false, errors: ['NOT_INSTALLED'] };
    if (compareVersions(v.manifest.version, cur.version) <= 0) return { ok: false, errors: ['NOT_NEWER'] };
    const dest = this.dirFor(id);
    const backup = path.join(this.cartridgesDir, `.backup-${id}`);
    const tmp = path.join(this.cartridgesDir, `.tmp-${id}-${crypto.randomBytes(6).toString('hex')}`);
    try {
      this._writeTree(tmp, v);
      fs.rmSync(backup, { recursive: true, force: true });
      fs.renameSync(dest, backup);
      try {
        fs.renameSync(tmp, dest);
      } catch (e) {
        fs.renameSync(backup, dest);
        throw e;
      }
    } catch {
      fs.rmSync(tmp, { recursive: true, force: true });
      return { ok: false, errors: ['UPDATE_FAILED'] };
    }
    const g = this.readGrants();
    const old = g[id] || {};
    g[id] = Object.fromEntries(v.manifest.capabilities.filter((c) => old[c] === true).map((c) => [c, true]));
    this.writeGrants(g);
    const newCapabilities = v.manifest.capabilities.filter((c) => !(cur.capabilities || []).includes(c));
    return { ok: true, errors: [], id, from: cur.version, to: v.manifest.version, newCapabilities };
  }

  // The installed cartridge as a ZIP again (same files, so it verifies the same way), for sending to another B.Link.
  exportZip(id) {
    if (!this.getManifest(id)) return null;
    const AdmZip = require('adm-zip'); const z = new AdmZip();
    const walk = (d, rel) => { for (const n of fs.readdirSync(d, { withFileTypes: true })) { const r = rel ? `${rel}/${n.name}` : n.name; if (n.isDirectory()) walk(path.join(d, n.name), r); else if (n.isFile()) z.addFile(r, fs.readFileSync(path.join(d, n.name))); } };
    walk(this.dirFor(id), '');
    return z.toBuffer();
  }

  hasBackup(id) {
    return typeof id === 'string' && ID_RE.test(id) && fs.existsSync(path.join(this.cartridgesDir, `.backup-${id}`));
  }

  rollback(id) {
    if (!this.getManifest(id)) return { ok: false, errors: ['NOT_INSTALLED'] };
    if (!this.hasBackup(id)) return { ok: false, errors: ['NO_BACKUP'] };
    const dest = this.dirFor(id);
    const backup = path.join(this.cartridgesDir, `.backup-${id}`);
    const swap = path.join(this.cartridgesDir, `.swap-${id}-${crypto.randomBytes(6).toString('hex')}`);
    try {
      fs.renameSync(dest, swap);
      fs.renameSync(backup, dest);
      fs.rmSync(swap, { recursive: true, force: true });
    } catch {
      return { ok: false, errors: ['ROLLBACK_FAILED'] };
    }
    const restored = this.getManifest(id);
    const g = this.readGrants();
    const old = g[id] || {};
    g[id] = Object.fromEntries((restored.capabilities || []).filter((c) => old[c] === true).map((c) => [c, true]));
    this.writeGrants(g);
    return { ok: true, errors: [], id, version: restored.version };
  }

  // Serves a file only if the manifest pins it and the bytes on disk still match the pin.
  pinnedFile(id, rel) {
    if (!this.isEnabled(id)) return null;
    const m = this.getManifest(id);
    if (!m || !m.files || !isSafeRelPath(rel) || !Object.prototype.hasOwnProperty.call(m.files, rel)) return null;
    let data;
    try {
      data = fs.readFileSync(path.join(this.dirFor(id), rel));
    } catch {
      return null;
    }
    if (sha256Hex(data) !== m.files[rel]) return null;
    return { data, mime: MIME[path.extname(rel).toLowerCase()] || 'application/octet-stream' };
  }

  remove(id) {
    if (!this.getManifest(id)) return { ok: false, errors: ['NOT_INSTALLED'] };
    fs.rmSync(this.dirFor(id), { recursive: true, force: true });
    fs.rmSync(path.join(this.cartridgesDir, `.backup-${id}`), { recursive: true, force: true });
    const g = this.readGrants();
    delete g[id];
    this.writeGrants(g);
    if (this.settings) this.settings.forget(id);
    return { ok: true, errors: [] };
  }

  readGrants() {
    try {
      const g = JSON.parse(fs.readFileSync(this.grantsFile, 'utf8'));
      return g && typeof g === 'object' && !Array.isArray(g) ? g : {};
    } catch {
      return {};
    }
  }

  writeGrants(g) {
    fs.writeFileSync(this.grantsFile, JSON.stringify(g, null, 2));
  }

  isGranted(id, cap) {
    const g = this.readGrants();
    return !!(g[id] && g[id][cap] === true);
  }

  setGrant(id, cap, value) {
    const m = this.getManifest(id);
    if (!m || !(m.capabilities || []).includes(cap)) return { ok: false, errors: ['CAPABILITY_NOT_DECLARED'] };
    const g = this.readGrants();
    g[id] = g[id] || {};
    g[id][cap] = value === true;
    this.writeGrants(g);
    return { ok: true, errors: [] };
  }

  // Keys and models come from the admin-managed settings. With no settings, both fail closed.
  getKey(provider) {
    return this.settings ? this.settings.getKey(provider) : null;
  }

  getModel(provider) {
    return this.settings ? this.settings.getModel(provider) : null;
  }

  isEnabled(id) {
    return !(this.settings && this.settings.isDisabled(id));
  }
}

module.exports = { Library, MIME, compareVersions };
