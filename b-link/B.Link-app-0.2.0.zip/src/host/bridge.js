'use strict';
// LLM bridge broker (trusted host side). Implements the operations in the City Link kit's
// DOCS/12 (bridge.providers, bridge.chat, bridge.cancel). Everything is checked in order:
// manifest capability, Human grant, strict argument shape, then provider availability.
const CAP = 'llm.chat';
const PROVIDERS = Object.freeze(['xai', 'openai']);
const PROVIDER_CODES = new Set(['PROVIDER_AUTH_FAILED', 'PROVIDER_RATE_LIMIT', 'PROVIDER_REQUEST_FAILED']);
const LIMITS = Object.freeze({ maxMessages: 40, maxMessageChars: 8000, maxTotalChars: 32000 });
const REQ_ID_RE = /^[A-Za-z0-9_-]{8,64}$/;

const ok = (result) => ({ ok: true, result });
const fail = (error) => ({ ok: false, error });
const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const keysOf = (o) => Object.keys(o).sort().join(',');

function validateMessages(m) {
  if (!Array.isArray(m) || m.length === 0) return { ok: false, error: 'BAD_MESSAGES' };
  if (m.length > LIMITS.maxMessages) return { ok: false, error: 'MESSAGE_LIMIT' };
  let total = 0;
  const out = [];
  for (const item of m) {
    if (!isPlainObject(item) || keysOf(item) !== 'content,role') return { ok: false, error: 'BAD_MESSAGES' };
    if (item.role !== 'user' && item.role !== 'assistant') return { ok: false, error: 'BAD_MESSAGES' };
    if (typeof item.content !== 'string' || item.content.length === 0) return { ok: false, error: 'BAD_MESSAGES' };
    if (item.content.length > LIMITS.maxMessageChars) return { ok: false, error: 'MESSAGE_LIMIT' };
    total += item.content.length;
    if (total > LIMITS.maxTotalChars) return { ok: false, error: 'MESSAGE_LIMIT' };
    out.push({ role: item.role, content: item.content });
  }
  return { ok: true, messages: out };
}

class LlmBridge {
  // library: { getManifest(id), isGranted(id, cap), getKey(provider), getModel(provider) }
  // providers: { [name]: async ({ apiKey, model, messages, signal }) => { text, usage } }
  constructor({ library, providers, timeoutMs = 45000, isKilled = () => false, onEvent = () => {}, modelResolver = null }) {
    this.modelResolver = modelResolver; // async (provider, apiKey, signal) => model id | null
    this.autoModels = new Map();
    this.library = library;
    this.isKilled = isKilled;
    this.onEvent = onEvent;
    this.providers = providers;
    this.timeoutMs = timeoutMs;
    this.active = new Map(); // cartridgeId -> { requestId, ac }
  }

  async handle(cartridgeId, req) {
    const res = await this._handle(cartridgeId, req);
    this.onEvent({ cartridgeId: String(cartridgeId), op: String((req && req.op) ?? '').slice(0, 40), result: res.ok ? 'OK' : res.error });
    return res;
  }

  async _handle(cartridgeId, req) {
    if (this.isKilled()) return fail('KILL_SWITCH_ON');
    if (!this.library.isEnabled(cartridgeId)) return fail('CARTRIDGE_DISABLED');
    try {
      const manifest = this.library.getManifest(cartridgeId);
      if (!manifest || !(manifest.capabilities || []).includes(CAP)) return fail('CAPABILITY_DENIED');
      if (!this.library.isGranted(cartridgeId, CAP)) return fail('PERMISSION_DENIED');
      const op = req && req.op;
      const args = req && req.args;
      if (op === 'bridge.providers') return this.providersOp();
      if (op === 'bridge.chat') return await this.chatOp(cartridgeId, args);
      if (op === 'bridge.cancel') return this.cancelOp(cartridgeId, args);
      return fail('BAD_MESSAGES');
    } catch {
      return fail('HOST_BRIDGE_TIMEOUT_OR_UNAVAILABLE');
    }
  }

  providersOp() {
    const configured = PROVIDERS.filter((p) => Object.hasOwn(this.providers, p) && this.library.getKey(p));
    return ok({ version: 1, providers: configured, capability: CAP, permission: 'host-managed' });
  }

  async chatOp(cartridgeId, args) {
    if (!isPlainObject(args) || keysOf(args) !== 'messages,provider,requestId') return fail('BAD_MESSAGES');
    const { provider, requestId, messages } = args;
    if (!PROVIDERS.includes(provider) || !Object.hasOwn(this.providers, provider)) return fail('PROVIDER_UNSUPPORTED');
    if (typeof requestId !== 'string' || !REQ_ID_RE.test(requestId)) return fail('BAD_MESSAGES');
    const checked = validateMessages(messages);
    if (!checked.ok) return fail(checked.error);
    if (this.active.has(cartridgeId)) return fail('BRIDGE_BUSY');
    const apiKey = this.library.getKey(provider);
    if (!apiKey) return fail('PROVIDER_NOT_CONFIGURED');

    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), this.timeoutMs);
    this.active.set(cartridgeId, { requestId, ac });
    let model = null;
    try {
      model = await this._model(provider, apiKey, ac.signal);
      if (!model) return fail('MODEL_NOT_CONFIGURED');
      if (ac.signal.aborted) return fail('BRIDGE_ABORTED_OR_TIMED_OUT');
      const out = await this.providers[provider]({ apiKey, model, messages: checked.messages, signal: ac.signal });
      return ok({
        text: String(out.text).slice(0, 20000),
        provider,
        model: 'host-selected',
        usage: { input: Number(out.usage && out.usage.input) || 0, output: Number(out.usage && out.usage.output) || 0 },
      });
    } catch (e) {
      if (ac.signal.aborted) return fail('BRIDGE_ABORTED_OR_TIMED_OUT');
      if (!this.library.getModel(provider)) this.autoModels.delete(provider);
      return fail(e && PROVIDER_CODES.has(e.code) ? e.code : 'PROVIDER_REQUEST_FAILED');
    } finally {
      clearTimeout(timer);
      this.active.delete(cartridgeId);
    }
  }

  // Admin "TEST": one tiny request through the same provider path, so a key and model can be checked.
  // The reply text never leaves the host; only success or an error code is returned.
  async selfTest(provider) {
    if (!PROVIDERS.includes(provider) || !Object.hasOwn(this.providers, provider)) return fail('PROVIDER_UNSUPPORTED');
    if (this.isKilled()) return fail('KILL_SWITCH_ON');
    const apiKey = this.library.getKey(provider);
    if (!apiKey) return fail('PROVIDER_NOT_CONFIGURED');
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), Math.min(this.timeoutMs, 20000));
    try {
      const auto = !this.library.getModel(provider);
      if (auto) this.autoModels.delete(provider);
      const model = await this._model(provider, apiKey, ac.signal);
      if (!model) return fail('MODEL_NOT_CONFIGURED');
      if (ac.signal.aborted) return fail('BRIDGE_ABORTED_OR_TIMED_OUT');
      const out = await this.providers[provider]({
        apiKey,
        model,
        messages: [{ role: 'user', content: 'Reply with the single word OK.' }],
        signal: ac.signal,
      });
      return ok({ replied: typeof out.text === 'string' && out.text.length > 0, model, auto });
    } catch (e) {
      if (ac.signal.aborted) return fail('BRIDGE_ABORTED_OR_TIMED_OUT');
      if (!this.library.getModel(provider)) this.autoModels.delete(provider);
      return fail(e && PROVIDER_CODES.has(e.code) ? e.code : 'PROVIDER_REQUEST_FAILED');
    } finally {
      clearTimeout(timer);
    }
  }

  // Model to use: the admin's choice if set, otherwise the provider's own best general model (looked up once).
  async _model(provider, apiKey, signal) {
    const set = this.library.getModel(provider);
    if (set) return set;
    if (this.autoModels.has(provider)) return this.autoModels.get(provider);
    if (!this.modelResolver) return null;
    const id = await this.modelResolver(provider, apiKey, signal);
    if (id) this.autoModels.set(provider, id);
    return id || null;
  }

  cancelOp(cartridgeId, args) {
    if (!isPlainObject(args) || keysOf(args) !== 'requestId' || typeof args.requestId !== 'string') {
      return fail('BAD_MESSAGES');
    }
    const a = this.active.get(cartridgeId);
    if (a && a.requestId === args.requestId) {
      a.ac.abort();
      return ok({ cancelled: true });
    }
    return ok({ cancelled: false });
  }
}

module.exports = { LlmBridge, validateMessages, CAP, PROVIDERS, LIMITS };
