'use strict';
// Narrow bridge from the B.Link UI to the host. The UI never receives keys, key material or file paths.
const { contextBridge, ipcRenderer } = require('electron');
const s = (v) => String(v);

contextBridge.exposeInMainWorld('blink', Object.freeze({
  listCartridges: () => ipcRenderer.invoke('library:list'),
  bridgeRequest: (cartridgeId, msg) => ipcRenderer.invoke('bridge:req', { cartridgeId: s(cartridgeId), msg }),
  adminStatus: () => ipcRenderer.invoke('admin:status'),
  adminSetup: (passphrase) => ipcRenderer.invoke('admin:setup', s(passphrase)),
  adminUnlock: (passphrase) => ipcRenderer.invoke('admin:unlock', s(passphrase)),
  adminLock: () => ipcRenderer.invoke('admin:lock'),
  settingsStatus: () => ipcRenderer.invoke('settings:status'),
  setKillSwitch: (on) => ipcRenderer.invoke('settings:killswitch', on === true),
  setProvider: (name, payload) => ipcRenderer.invoke('settings:provider', s(name), payload || {}),
  testProvider: (name) => ipcRenderer.invoke('settings:test', s(name)),
  installCartridge: () => ipcRenderer.invoke('library:install'),
  updateCartridge: () => ipcRenderer.invoke('library:update'),
  rollbackCartridge: (id) => ipcRenderer.invoke('library:rollback', s(id)),
  setEmbeds: (id, list) => ipcRenderer.invoke('embeds:set', s(id), Array.isArray(list) ? list.map(s) : []),
  removeCartridge: (id) => ipcRenderer.invoke('library:remove', s(id)),
  setEnabled: (id, on) => ipcRenderer.invoke('library:setEnabled', s(id), on === true),
  setGrant: (id, cap, v) => ipcRenderer.invoke('grants:set', s(id), s(cap), v === true),
  speechStatus: () => ipcRenderer.invoke('speech:status'),
  speechPlayed: (ok, error) => ipcRenderer.invoke('speech:played', { ok: ok === true, error: error ? String(error) : '' }),
  speechSay: (text) => ipcRenderer.invoke('speech:say', s(text)),
  speechListen: (samples, rate, send) => ipcRenderer.invoke('speech:listen', { samples, rate: Number(rate), send: send === true }),
  setSpeech: (patch) => ipcRenderer.invoke('speech:settings', patch || {}),
  onSpeechPlay: (fn) => ipcRenderer.on('speech:play', (_e, wav) => fn(wav)),
  onSpeechStop: (fn) => ipcRenderer.on('speech:stop', () => fn()),
  onPushToTalk: (fn) => ipcRenderer.on('speech:ptt', (_e, m) => fn({ down: m && m.down === true, send: m && m.send === true })),
  quit: () => ipcRenderer.invoke('app:quit'),
  auditRecent: (n) => ipcRenderer.invoke('audit:recent', Number(n) || 50),
}));
