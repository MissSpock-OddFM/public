'use strict';
// B.Link shell. One fixed screen at a time, keyed menus, paged lists, no scrolling anywhere.
// Keys: arrows or Tab move, Enter picks, number keys jump, PgUp/PgDn page, Esc goes back, F1 shelf, F2 admin,
//       F11 full screen, F9 hold to dictate, F10 hold to dictate and send, F8 stop speaking.
const $ = (sel) => document.querySelector(sel);
const S = { carts: [], active: null, screen: 'shelf', page: { shelf: 0, cart: 0, audit: 0 }, ari: [], notes: {}, voice: null };

// DOM is built with textContent only, so cartridge names can never inject markup.
function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'text') n.textContent = v;
    else if (k === 'class') n.className = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  n.append(...kids);
  return n;
}
const errs = (r) => (r && r.errors ? r.errors.join(', ') : (r && r.error) || '');
const say = (m, bad = false) => { const n = $('#msg'); n.textContent = m; n.className = bad ? 'bad' : ''; };
const btn = (label, fn, o = {}) => {
  const b = el('button', { type: 'button', class: `k${o.cls ? ' ' + o.cls : ''}`, text: label, onclick: fn });
  if (o.hot) b.dataset.hot = String(o.hot);
  if (o.page) b.dataset.page = o.page;
  if (o.disabled) b.disabled = true;
  return b;
};
const toggle = (label, on, fn) => {
  const b = el('button', { type: 'button', class: `k ${on ? 'on' : 'off'}`, text: label });
  b.addEventListener('click', () => fn(!on));
  return b;
};
function field(label, input) { return el('label', { class: 'field' }, el('span', { text: label }), input); }
function show(...nodes) { $('#view').replaceChildren(...nodes); const f = $('#view').querySelector('input, button.k:not(:disabled)'); if (f) f.focus(); }
function pager(key, total, perPage, redraw) {
  const pages = Math.max(1, Math.ceil(total / perPage));
  S.page[key] = Math.min(S.page[key], pages - 1);
  const p = S.page[key];
  const go = (d) => { S.page[key] = (p + d + pages) % pages; redraw(); };
  return { p, pages, from: p * perPage, to: p * perPage + perPage, bar: pages > 1
    ? el('div', { class: 'pager' }, btn('< PREV', () => go(-1), { page: 'prev' }), el('span', { text: `PAGE ${p + 1} OF ${pages}` }), btn('NEXT >', () => go(1), { page: 'next' }))
    : el('div', { class: 'pager' }, el('span', { text: total === 0 ? '' : 'PAGE 1 OF 1' })) };
}

// Soft-key bar.
function updBtn() {
  if (!S.update) return document.createTextNode('');
  const u = S.update;
  if (u.updating) return el('span', { class: 'warnbtn', text: `UPDATING TO ${u.version}... B.LINK WILL RESTART` });
  return btn(u.canAuto ? `UPDATE TO ${u.version}` : `UPDATE ${u.version} READY`, async () => {
    if (!u.canAuto) return say(`B.LINK ${u.version} IS AVAILABLE. RUN B.LINK-SETUP.EXE ONCE, THEN IT UPDATES ITSELF.`, true);
    say('UPDATING... B.LINK WILL RESTART.');
    const r = await window.blink.applyUpdate();
    if (!r || !r.ok) say(`COULD NOT START THE UPDATE (${r && r.error}). RUN B.LINK-SETUP.EXE.`, true);
  }, { cls: 'warnbtn' });
}
function keysBar() {
  const k = $('#keys');
  const chip = el('span', { id: 'chip', class: 'chip', text: S.chip || '' });
  if (S.active) {
    k.replaceChildren(btn('HOME', closeStage), el('span', { text: S.voiceOn ? 'VOICE ON' : 'VOICE OFF' }), el('span', { class: 'dim', text: 'F9 DICTATE  F8 HUSH  F11 SCREEN' }), el('span', { class: 'spacer' }), updBtn(), chip, btn('QUIT', () => window.blink.quit(), { cls: 'danger' }));
  } else {
    k.replaceChildren(btn('F1 SHELF', () => go('shelf')), btn('F2 ADMIN', () => go('admin')), btn('F3 BETTY', () => go('betty')), el('span', { class: 'dim', text: 'F11 FULL SCREEN' }), el('span', { class: 'spacer' }), updBtn(), chip, btn('QUIT', () => window.blink.quit(), { cls: 'danger' }));
  }
}
function setChip(t) { S.chip = t; const c = $('#chip'); if (c) c.textContent = t; }

function go(screen) {
  if (S.active) closeStage();
  S.screen = screen;
  say('');
  keysBar();
  if (screen === 'shelf') return drawShelf();
  if (screen === 'admin') return drawAdmin();
  if (screen === 'keys') return drawKeys();
  if (screen === 'carts') return drawCarts();
  if (screen === 'voice') return drawVoice();
  if (screen === 'betty') return drawBetty();
  if (screen === 'usage') return drawUsage();
  if (screen === 'models') return drawModels();
  if (screen === 'audit') return drawAudit();
}

async function refreshCarts() { S.carts = await window.blink.listCartridges(); }

// ---- SHELF ----
async function drawShelf() {
  await refreshCarts();
  const per = 5;
  const pg = pager('shelf', S.carts.length, per, drawShelf);
  const rows = S.carts.slice(pg.from, pg.to).map((c, i) => el('div', { class: 'box' },
    el('div', { class: 'line' }, el('span', { class: 'num', text: String(i + 1) }), el('span', { class: 'grow', text: c.name.toUpperCase() }), el('span', { class: 'dim', text: `v${c.version}` }),
      btn(c.enabled ? 'RUN' : 'OFF BY ADMIN', () => launch(c.id), { hot: i + 1, disabled: !c.enabled })),
    el('div', { class: 'line dim' }, el('span', { class: 'num' }), el('span', { class: 'grow', text: c.description || c.id }))));
  show(el('h2', { text: 'SHELF  ' + (S.carts.length ? `${S.carts.length} CARTRIDGE${S.carts.length > 1 ? 'S' : ''}` : '') }),
    ...(rows.length ? rows : [el('p', { class: 'dim', text: 'THE SHELF IS EMPTY. AN ADMINISTRATOR CAN INSTALL CARTRIDGES UNDER F2 ADMIN.' })]), pg.bar);
}

// ---- BETTY: B.Link's own assistant (part of the terminal, not a cartridge) ----
function drawBetty() {
  const tx = el('div', { class: 'tx' });
  const input = el('input', { type: 'text', maxlength: '1000', placeholder: 'TYPE OR HOLD F9 AND SPEAK', autocomplete: 'off', spellcheck: 'false' });
  let busy = false;
  const paint = () => {
    const rows = S.ari.length ? S.ari : [{ role: 'assistant', content: 'Ask me how to use B.Link, or just talk. Hold or tap F9 to speak.' }];
    tx.replaceChildren(...rows.slice(-8).map((t) => el('p', { class: t.role === 'user' ? 'you' : 'her', text: `${t.role === 'user' ? 'YOU' : 'BETTY'} > ${t.content}` })));
  };
  const send = async () => {
    const text = input.value.trim();
    if (!text || busy) return;
    busy = true; input.value = '';
    S.ari.push({ role: 'user', content: text }); S.ari = S.ari.slice(-20); paint();
    say('BETTY IS THINKING...'); setChip('THINKING');
    const r = await window.blink.askBetty(S.ari);
    busy = false; setChip('');
    if (r && r.ok) { S.ari.push({ role: 'assistant', content: r.text }); say(''); }
    else {
      S.ari.pop();
      const why = { PROVIDER_NOT_CONFIGURED: 'NO AI KEY SAVED. ADD ONE UNDER F2 ADMIN, AI KEYS.', KILL_SWITCH_ON: 'THE KILL SWITCH IS ON.', BUDGET_REACHED: 'THE DAILY API LIMIT IS REACHED. RAISE IT UNDER F2 ADMIN, USAGE & LIMIT.', MODEL_NOT_CONFIGURED: 'NO MODEL FOUND FOR THE KEY. USE TEST UNDER AI KEYS.' }[r && r.error] || `BETTY COULD NOT ANSWER (${r && r.error}).`;
      say(why, true); input.value = text;
    }
    paint(); input.focus();
  };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); send(); } });
  paint();
  show(el('h2', { text: 'BETTY  BUILT-IN ASSISTANT' }), el('div', { class: 'box grow' }, tx), el('div', { class: 'line' }, el('span', { class: 'num', text: '>' }), input, btn('SEND', send)));
  input.focus();
}

// ---- STAGE ----
async function launch(id) {
  const c = S.carts.find((x) => x.id === id);
  if (!c || !c.enabled) return;
  const frame = el('iframe', { class: 'cart-frame', title: c.name, sandbox: 'allow-scripts allow-same-origin allow-forms', src: `blink-cart://${c.id}/${c.entry}` });
  frame.addEventListener('load', () => frame.focus());
  S.active = { id: c.id, frame };
  try { const sp = await window.blink.speechStatus(); S.voiceOn = !!(sp.tts && sp.readAloud); } catch { S.voiceOn = false; }
  $('#term').classList.add('stage');
  const need = c.capabilities.filter((cap) => !c.granted[cap]);
  const bar = need.length ? el('div', { class: 'warnbar' }, el('span', { text: `THIS CARTRIDGE ASKS FOR ${need.join(', ').toUpperCase()}. NOT ALLOWED YET.` }), btn('OPEN ADMIN', () => go('admin'))) : null;
  say('');
  keysBar();
  $('#view').replaceChildren(...(bar ? [bar] : []), frame);
}
function closeStage() {
  S.active = null;
  $('#term').classList.remove('stage');
  $('#view').replaceChildren();
  S.screen = 'shelf';
  keysBar();
  drawShelf();
}

// ---- Bridge: only the frame B.Link created may talk to the host, and only as its own id ----
window.addEventListener('message', async (e) => {
  const act = S.active;
  if (!act || e.source !== act.frame.contentWindow) return;
  const m = e.data;
  if (!m || m.clink !== 1 || m.type !== 'req' || typeof m.id !== 'string' || m.id.length > 80) return;
  const res = await window.blink.bridgeRequest(act.id, { op: String(m.op), args: m.args });
  if (S.active !== act) return;
  act.frame.contentWindow.postMessage({ clink: 1, type: 'res', id: m.id, ...res }, '*');
});

// ---- ADMIN ----
async function drawAdmin() {
  const s = await window.blink.adminStatus();
  if (s.setUp && !s.unlocked) return drawUnlock();
  const st = await window.blink.settingsStatus();
  if (lockedOut(st)) return;
  const prevV = await window.blink.previousVersion();
  const item = (n, label, value, fn, cls) => el('div', { class: 'line' }, el('span', { class: 'num', text: String(n) }), btn(label, fn, { hot: n, cls }), el('span', { class: 'grow dim', text: value }));
  show(el('h2', { text: 'ADMINISTRATOR' }),
    el('div', { class: 'box' },
      item(1, 'KILL SWITCH', st.killSwitch ? 'ON: ALL AI CALLS STOPPED' : 'OFF', async () => { const r = await window.blink.setKillSwitch(!st.killSwitch); if (lockedOut(r)) return; say(r.ok ? (st.killSwitch ? 'AI calls restored.' : 'KILL SWITCH ON. No cartridge can reach an AI.') : `Refused: ${errs(r)}`, !r.ok); drawAdmin(); }, st.killSwitch ? 'danger' : ''),
      item(2, 'AI KEYS', `OPENAI ${st.providers.openai.configured ? 'KEY SAVED' : 'NO KEY'}   GROK ${st.providers.xai.configured ? 'KEY SAVED' : 'NO KEY'}`, () => go('keys')),
      item(3, 'CARTRIDGES', 'INSTALL, UPDATE, PERMISSIONS, REMOVE', () => go('carts')),
      item(4, 'VOICE', 'SPEAKER, LISTENER, DICTATION', () => go('voice')),
      item(8, 'USAGE & LIMIT', 'WHAT THE AI KEYS HAVE COST, AND A DAILY STOP', () => go('usage')),
      item(5, 'AUDIT LOG', 'EVERY ADMIN ACTION, NO SECRETS', () => go('audit')),
      item(9, 'PASSWORD', s.setUp ? 'ON (PRESS 9 TO TURN OFF)' : 'OFF: NO PASSWORD NEEDED (PRESS 9 TO ADD ONE)', async () => { if (!s.setUp) return drawSetup(); const r = await window.blink.adminRemovePassword(); if (lockedOut(r)) return; say(r.ok ? 'Password turned off.' : `Refused: ${errs(r)}`, !r.ok); drawAdmin(); }),
      prevV ? el('div', { class: 'line' }, el('span', { class: 'num', text: 'R' }), btn('ROLL BACK', async () => { const r = await window.blink.rollback(); if (lockedOut(r)) return; say(r.ok ? `GOING BACK TO ${prevV}... B.LINK WILL RESTART.` : `Refused: ${errs(r)}`, !r.ok); }), el('span', { class: 'grow dim', text: `GO BACK TO THE PREVIOUS VERSION (${prevV}). ALSO HAPPENS BY ITSELF IF A VERSION WILL NOT START.` })) : document.createTextNode(''),
      item(6, 'LOCK', 'END THE ADMIN SESSION NOW', async () => { await window.blink.adminLock(); say(s.setUp ? 'Locked.' : 'No password is set, so nothing to lock.'); go('shelf'); }),
      item(7, 'AUTO-LOCK', { 0: 'NEVER WHILE B.LINK IS OPEN (PRESS 7 TO CHANGE)', 10: 'AFTER 10 IDLE MINUTES (PRESS 7 TO CHANGE)', 60: 'AFTER 1 IDLE HOUR (PRESS 7 TO CHANGE)' }[st.lockMinutes ?? 0], async () => { const next = { 0: 10, 10: 60, 60: 0 }[st.lockMinutes ?? 0]; const r = await window.blink.setLockMinutes(next); if (lockedOut(r)) return; say(r.ok ? 'Auto-lock changed.' : `Refused: ${errs(r)}`, !r.ok); drawAdmin(); })),
    el('p', { class: 'dim', text: 'NO PASSWORD IS NEEDED UNLESS YOU TURN ONE ON (9). KEYS ARE KEPT ENCRYPTED AND ARE NEVER SHOWN.' }));
}
function lockedOut(r) {
  if (r && Array.isArray(r.errors) && r.errors.includes('ADMIN_LOCKED')) { say('Admin session locked. Unlock again.', true); S.screen = 'admin'; drawAdmin(); return true; }
  return false;
}
const back = () => btn('< BACK', () => go('admin'));

function drawSetup() {
  const p1 = el('input', { type: 'password', autocomplete: 'new-password' });
  const p2 = el('input', { type: 'password', autocomplete: 'new-password' });
  const doit = async () => {
    if (p1.value !== p2.value) return say('Passphrases do not match.', true);
    const r = await window.blink.adminSetup(p1.value);
    if (!r.ok) return say(`Setup refused: ${errs(r)}`, true);
    say('Password on.'); drawAdmin();
  };
  p2.addEventListener('keydown', (e) => { if (e.key === 'Enter') doit(); });
  show(el('div', { class: 'center box' }, el('h2', { text: 'ADD A PASSWORD (OPTIONAL)' }),
    el('p', { class: 'dim', text: '12 OR MORE CHARACTERS. ONLY A HASH IS KEPT. IF YOU FORGET IT, TYPE RESET ON THE LOCK SCREEN.' }),
    field('PASS', p1), field('AGAIN', p2), btn('SET PASSPHRASE', doit)));
}
function drawUnlock() {
  const rw = el('input', { type: 'text' });
  const p = el('input', { type: 'password', autocomplete: 'current-password' });
  const doit = async () => {
    const r = await window.blink.adminUnlock(p.value); p.value = '';
    if (!r.ok) return say(`Unlock refused: ${errs(r)}`, true);
    say('Unlocked.'); drawAdmin();
  };
  p.addEventListener('keydown', (e) => { if (e.key === 'Enter') doit(); });
  show(el('div', { class: 'center box' }, el('h2', { text: 'ADMINISTRATOR' }), field('PASS', p), btn('UNLOCK', doit),
    el('p', { class: 'dim', text: 'FORGOT IT? TYPE RESET BELOW. THIS ONLY REMOVES THE PASSWORD; KEYS STAY SAFE.' }),
    field('WORD', rw), btn('REMOVE PASSWORD', async () => { const r = await window.blink.adminReset(rw.value); if (!r.ok) return say('Type the word RESET exactly.', true); say('Password removed.'); drawAdmin(); })));
}

// ---- AI KEYS ----
async function drawKeys() {
  const st = await window.blink.settingsStatus();
  if (lockedOut(st)) return;
  const WHY = {
    PROVIDER_AUTH_FAILED: 'The provider refused the key. Paste it again.', PROVIDER_NOT_CONFIGURED: 'No key is saved yet.',
    MODEL_NOT_CONFIGURED: 'No model is set and none could be found.', PROVIDER_RATE_LIMIT: 'The provider says slow down, or out of credit.',
    PROVIDER_REQUEST_FAILED: 'The provider could not answer. Check the model name, internet or credit.', BRIDGE_ABORTED_OR_TIMED_OUT: 'Timed out. Try again.',
    KILL_SWITCH_ON: 'The kill switch is on.', ENCRYPTION_UNAVAILABLE: 'This computer cannot encrypt keys.',
  };
  const cards = ['openai', 'xai'].map((name) => {
    const label = name === 'xai' ? 'GROK (xAI)' : 'OPENAI';
    const p = st.providers[name];
    const model = el('input', { type: 'text', value: p.model || '', placeholder: 'EMPTY = AUTOMATIC' });
    const key = el('input', { type: 'password', autocomplete: 'off', placeholder: p.configured ? 'KEY SAVED (TYPE TO REPLACE)' : 'PASTE API KEY' });
    const note = el('p', { class: S.notes[name] && S.notes[name].startsWith('FAILED') ? 'bad' : 'good', text: S.notes[name] || '' });
    const set = (m) => { S.notes[name] = m; note.textContent = m; note.className = m.startsWith('FAILED') || m.startsWith('Refused') ? 'bad' : 'good'; say(m, m.startsWith('FAILED') || m.startsWith('Refused')); };
    return el('div', { class: 'box' }, el('h3', { text: `${label}: ${p.configured ? 'KEY SAVED' : 'NO KEY'}` }), field('MODEL', model), field('KEY', key),
      el('div', { class: 'row' },
        btn('SAVE', async () => {
          const payload = {}; if (model.value.trim()) payload.model = model.value.trim(); if (key.value) payload.apiKey = key.value; key.value = '';
          const r = await window.blink.setProvider(name, payload); if (lockedOut(r)) return;
          set(r.ok ? `${label} saved.` : `Refused: ${errs(r)} ${WHY[errs(r)] || ''}`); if (r.ok) drawKeys();
        }),
        btn('PICK MODEL', () => { S.modelFor = name; S.page.models = 0; go('models'); }),
        btn('TEST', async () => {
          set(`Testing ${label}... one tiny request`);
          const r = await window.blink.testProvider(name); if (lockedOut(r)) return;
          set(r.ok ? `PASSED. ${label} answered. Model: ${r.result.model}${r.result.auto ? ' (picked automatically)' : ''}.` : `FAILED: ${r.error || errs(r)}. ${WHY[r.error || errs(r)] || ''}`);
        }),
        btn('CLEAR KEY', async () => { const r = await window.blink.setProvider(name, { apiKey: null }); if (lockedOut(r)) return; set(r.ok ? `${label} key cleared.` : `Refused: ${errs(r)}`); if (r.ok) drawKeys(); }, { cls: 'danger' })),
      note);
  });
  show(el('div', { class: 'row' }, back(), el('h2', { class: 'grow', text: 'AI KEYS' })), ...cards);
}

// ---- CARTRIDGES (one per page) ----
async function drawCarts() {
  const st = await window.blink.settingsStatus();
  if (lockedOut(st)) return;
  await refreshCarts();
  const pg = pager('cart', S.carts.length, 1, drawCarts);
  const c = S.carts[pg.from];
  const sure = (key, label, fn) => { let armed = false; const b = btn(label, async () => { if (!armed) { armed = true; b.textContent = `SURE? ${label}`; setTimeout(() => { armed = false; b.textContent = label; }, 4000); return; } await fn(); }, { cls: 'danger' }); return b; };
  const body = [];
  if (!c) body.push(el('p', { class: 'dim', text: 'NO CARTRIDGES INSTALLED.' }));
  else {
    const act = async (p, okMsg, redraw = true) => { const r = await p; if (lockedOut(r)) return; say(r.ok ? okMsg : `Refused: ${errs(r)}`, !r.ok); if (redraw) drawCarts(); };
    const rows = [
      toggle('ENABLED', c.enabled, (v) => act(window.blink.setEnabled(c.id, v), `${c.name} ${v ? 'enabled' : 'disabled'}.`)),
      ...c.capabilities.map((cap) => toggle(`${cap.toUpperCase()} PERMISSION`, !!c.granted[cap], (v) => act(window.blink.setGrant(c.id, cap, v), `${cap} ${v ? 'granted to' : 'revoked from'} ${c.name}.`))),
      toggle('MIXCLOUD AUDIO PLAYER', (c.embeds || []).includes('mixcloud'), (v) => act(window.blink.setEmbeds(c.id, v ? ['mixcloud'] : []), `Mixcloud ${v ? 'allowed' : 'blocked'} for ${c.name}. RUN it again to apply.`)),
    ];
    body.push(el('div', { class: 'box' }, el('h3', { text: `${c.name.toUpperCase()}  v${c.version}` }), el('p', { class: 'dim', text: c.id }), ...rows,
      el('div', { class: 'row' }, ...(c.hasBackup ? [sure('rb', 'ROLLBACK', () => act(window.blink.rollbackCartridge(c.id), `${c.name} rolled back.`))] : []), sure('rm', 'REMOVE', () => act(window.blink.removeCartridge(c.id), `${c.name} removed.`)))));
  }
  const inst = async () => { say('Opening install dialog...'); const r = await window.blink.installCartridge(); if (lockedOut(r)) return; say(r.ok ? `Installed ${r.id}.` : (r.errors.includes('CANCELLED') ? 'Install cancelled.' : `Install refused: ${errs(r)}`), !r.ok && !r.errors.includes('CANCELLED')); drawCarts(); };
  const upd = async () => { say('Opening update dialog...'); const r = await window.blink.updateCartridge(); if (lockedOut(r)) return;
    say(r.ok ? `Updated ${r.id}: ${r.from} to ${r.to}.${r.newCapabilities.length ? ` New permission requests start closed: ${r.newCapabilities.join(', ')}.` : ''}` : r.errors.includes('CANCELLED') ? 'Update cancelled.' : r.errors.includes('NOT_NEWER') ? 'That ZIP is not newer than the installed version.' : `Update refused: ${errs(r)}`, !r.ok && !r.errors.includes('CANCELLED')); drawCarts(); };
  show(el('div', { class: 'row' }, back(), el('h2', { class: 'grow', text: `CARTRIDGES ${S.carts.length ? `${pg.p + 1} OF ${S.carts.length}` : ''}` })), ...body,
    el('div', { class: 'row' }, btn('INSTALL ZIP', inst), btn('UPDATE ZIP', upd)), pg.bar);
}

// ---- VOICE ----
async function drawVoice() {
  const st = await window.blink.settingsStatus();
  if (lockedOut(st)) return;
  const sp = await window.blink.speechStatus();
  const voices = sp.voices || [];
  const idx = Math.max(0, voices.indexOf(sp.voice));
  const apply = async (patch, msg) => { const r = await window.blink.setSpeech(patch); if (lockedOut(r)) return; say(r.ok ? msg : `Refused: ${errs(r)}`, !r.ok); drawVoice(); };
  const cyc = (d) => voices.length ? apply({ voice: voices[(idx + d + voices.length) % voices.length] }, 'Voice changed.') : say('No voices installed.', true);
  show(el('div', { class: 'row' }, back(), el('h2', { class: 'grow', text: 'VOICE' })),
    el('div', { class: 'box' },
      el('div', { class: 'line' }, el('span', { class: 'grow', text: 'SPEAKER (PIPER)' }), el('span', { class: sp.tts ? 'good' : 'bad', text: sp.tts ? 'READY' : 'NOT INSTALLED' })),
      el('div', { class: 'line' }, el('span', { class: 'grow', text: 'LISTENER (WHISPER TINY)' }), el('span', { class: sp.stt ? 'good' : 'bad', text: sp.stt ? 'READY' : 'NOT INSTALLED' })),
      el('div', { class: 'row' }, el('span', { class: 'dim', text: 'VOICE' }), btn('<', () => cyc(-1)), el('span', { text: voices.length ? voices[idx] : 'NONE' }), btn('>', () => cyc(1))),
      el('div', { class: 'row' }, el('span', { class: 'dim', text: 'SPEED' }), btn('-', () => apply({ speed: Math.max(0.6, +(sp.speed - 0.1).toFixed(2)) }, 'Slower.')), el('span', { text: sp.speed.toFixed(1) }), btn('+', () => apply({ speed: Math.min(1.6, +(sp.speed + 0.1).toFixed(2)) }, 'Faster.'))),
      toggle('READ AI REPLIES ALOUD', sp.readAloud, (v) => apply({ readAloud: v }, v ? 'Replies will be read aloud.' : 'Replies stay silent.')),
      el('div', { class: 'row' }, btn('TEST VOICE', async () => { const r = await window.blink.speechSay('Hello. This is the B dot Link terminal voice.'); say(r.ok ? 'Speaking...' : `Cannot speak: ${r.error}`, !r.ok); }))),
    el('div', { class: 'box' }, el('p', { text: 'F9 HOLD  DICTATE INTO WHATEVER IS ON SCREEN' }), el('p', { text: 'F10 HOLD DICTATE AND PRESS ENTER' }), el('p', { text: 'F8       HUSH' })),
    ...(sp.tts && sp.stt ? [] : [el('p', { class: 'bad', text: 'THE VOICE PACK IS NOT FULLY INSTALLED. RUN THE VOICE STEP FROM THE CHAT.' })]));
}

// ---- MODEL PICKER ----
async function drawModels() {
  const name = S.modelFor || 'openai';
  const label = name === 'xai' ? 'GROK (xAI)' : 'OPENAI';
  const r = await window.blink.listModels(name);
  if (lockedOut(r)) return;
  if (!r.ok) { show(el('div', { class: 'row' }, btn('< BACK', () => go('keys')), el('h2', { class: 'grow', text: `${label} MODELS` })), el('p', { class: 'bad', text: `COULD NOT LIST MODELS: ${r.error}. SAVE A WORKING KEY FIRST.` })); return; }
  S.page.models = S.page.models || 0;
  const rows = [{ id: '', label: `AUTOMATIC (NOW: ${r.auto || 'NONE'})`, price: r.auto && r.models.find((m) => m.id === r.auto) ? r.models.find((m) => m.id === r.auto).price : null }, ...r.models.map((m) => ({ id: m.id, label: m.id, price: m.price }))];
  const per = 6;
  const pg = pager('models', rows.length, per, drawModels);
  const priceTxt = (p) => (p ? `$${p[0]} IN / $${p[1]} OUT PER MILLION` : (name === 'xai' ? 'COST SHOWN IN USAGE' : 'PRICE UNKNOWN'));
  const pick = async (id) => { const x = await window.blink.setProvider(name, { model: id }); if (lockedOut(x)) return; say(x.ok ? (id ? `Model set to ${id}.` : 'Model set to automatic.') : `Refused: ${errs(x)}`, !x.ok); drawModels(); };
  const cur = r.current || '';
  show(el('div', { class: 'row' }, btn('< BACK', () => go('keys')), el('h2', { class: 'grow', text: `${label} MODELS  IN USE: ${cur || 'AUTOMATIC'}` })),
    el('div', { class: 'box' }, ...rows.slice(pg.from, pg.to).map((m, i) => el('div', { class: 'line' }, el('span', { class: 'num', text: String(i + 1) }), el('span', { class: 'grow', text: `${m.label}  ${priceTxt(m.price)}` }), btn(m.id === cur ? 'IN USE' : 'USE', () => pick(m.id), { hot: i + 1, disabled: m.id === cur })))),
    el('p', { class: 'dim', text: 'THE CHEAPEST OF THE NEWEST MODELS IS THE AUTOMATIC CHOICE. NEWER OR PRO MODELS COST MORE PER WORD: WATCH THE USAGE METER.' }), pg.bar);
}

// ---- USAGE METER ----
const money = (n) => (n >= 1 ? `$${n.toFixed(2)}` : `$${n.toFixed(4)}`);
const kfmt = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(2)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}K` : String(n));
function paintCost(todayUsd, limitUsd) {
  const n = $('#cost'); if (!n) return;
  n.textContent = `API TODAY ${money(todayUsd)}${limitUsd > 0 ? ` OF $${limitUsd}` : ''}`;
  n.className = `cost${limitUsd > 0 && todayUsd >= limitUsd * 0.8 ? ' warn' : ''}`;
}
async function refreshCost() { try { const u = await window.blink.usageSummary(); paintCost(u.todayUsd || 0, u.budget ? u.budget.dailyLimitUsd : 0); } catch {} }
window.blink.onUsage((m) => paintCost(m.todayUsd, m.limitUsd));

async function drawUsage() {
  const st = await window.blink.settingsStatus();
  if (lockedOut(st)) return;
  const u = await window.blink.usageSummary();
  const names = { openai: 'OPENAI', xai: 'GROK (xAI)' };
  const rowsFor = (label, by) => ['openai', 'xai'].map((p) => {
    const a = by[p] || { calls: 0, in: 0, out: 0, usd: 0, unpriced: 0, estimated: 0 };
    const note = a.unpriced ? ' +?' : a.estimated ? ' ~' : '';
    return [`${label} ${names[p]}`, String(a.calls), kfmt(a.in), kfmt(a.out), `${money(a.usd)}${note}`];
  });
  const cells = [];
  for (const [l, by] of [['TODAY', u.today], ['MONTH', u.month], ['ALL', u.all]]) for (const r of rowsFor(l, by)) cells.push(...r.map((t, i) => el('span', { class: i === 0 ? '' : 'dim', text: t })));
  const lim = u.budget.dailyLimitUsd;
  const steps = u.dayLimits;
  const apply = async (patch, msg) => { const r = await window.blink.setUsage(patch); if (lockedOut(r)) return; say(r.ok ? msg : `Refused: ${errs(r)}`, !r.ok); await refreshCost(); drawUsage(); };
  const stepLimit = (d) => apply({ dailyLimitUsd: steps[(steps.indexOf(lim) + d + steps.length) % steps.length] }, 'Daily limit changed.');
  const priceBox = (p) => {
    const cur = u.budget.priceOverrides[p] || { in: 0, out: 0 };
    const i = el('input', { type: 'text', value: cur.in ? String(cur.in) : '', placeholder: 'IN', maxlength: '8' });
    const o = el('input', { type: 'text', value: cur.out ? String(cur.out) : '', placeholder: 'OUT', maxlength: '8' });
    return el('div', { class: 'row' }, el('span', { class: 'dim', text: `${names[p]} $ PER MILLION TOKENS` }), i, o, btn('SAVE', () => apply({ price: { provider: p, in: Number(i.value) || 0, out: Number(o.value) || 0 } }, 'Price saved.')));
  };
  show(el('div', { class: 'row' }, back(), el('h2', { class: 'grow', text: 'USAGE & LIMIT' })),
    el('div', { class: 'box' },
      el('div', { class: 'usage-table' }, ...['', 'CALLS', 'TOKENS IN', 'TOKENS OUT', 'COST'].map((t) => el('span', { class: 'h', text: t })), ...cells),
      el('p', { class: 'dim', text: 'GROK COSTS ARE EXACT (REPORTED BY xAI). OPENAI COSTS ARE ESTIMATES (~) FROM PUBLISHED PRICES. +? = A CALL WITH NO KNOWN PRICE.' })),
    el('div', { class: 'box' },
      el('div', { class: 'row' }, el('span', { class: 'dim', text: 'DAILY LIMIT' }), btn('<', () => stepLimit(-1)), el('span', { text: lim ? `$${lim} A DAY. AI STOPS WHEN REACHED.` : 'NO LIMIT' }), btn('>', () => stepLimit(1))),
      el('p', { class: 'dim', text: 'LEAVE PRICES BLANK TO USE THE BUILT-IN OPENAI LIST. FILL THEM TO OVERRIDE (OPENAI ESTIMATE ONLY).' }),
      priceBox('openai')));
}

// ---- AUDIT (paged) ----
async function drawAudit() {
  const r = await window.blink.auditRecent(120);
  if (lockedOut(r)) return;
  const lines = (r.lines || []).slice().reverse();
  const per = 11;
  const pg = pager('audit', lines.length, per, drawAudit);
  const fmt = (l) => { const t = (l.t || '').slice(11, 19); const { t: _t, event, ...rest } = l; return `${t}  ${event || ''}  ${Object.entries(rest).filter(([, v]) => v !== undefined && !(Array.isArray(v) && !v.length)).map(([k, v]) => `${k}=${typeof v === 'object' ? JSON.stringify(v) : v}`).join(' ')}`; };
  show(el('div', { class: 'row' }, back(), el('h2', { class: 'grow', text: 'AUDIT LOG  NEWEST FIRST' })),
    ...(lines.length ? lines.slice(pg.from, pg.to).map((l) => el('div', { class: 'audit-line', text: fmt(l) })) : [el('p', { class: 'dim', text: 'NO EVENTS YET.' })]), pg.bar);
}

// ---- SPEECH CLIENT: playback and push to talk ----
// Playback goes through one Web Audio context that stays open with a near-silent dither stream, so the
// sound hardware is already awake when Betty speaks (no clipped or garbled first words).
let actx = null, playing = null;
function audioCtx() {
  if (actx) return actx;
  actx = new AudioContext();
  const n = actx.sampleRate, b = actx.createBuffer(1, n, n), d = b.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() - 0.5) * (2 / 32768); // about one bit of noise: inaudible, keeps the device awake
  const keep = actx.createBufferSource(); keep.buffer = b; keep.loop = true; keep.connect(actx.destination); keep.start();
  return actx;
}
function stopSpeaking() { if (playing) { try { playing.stop(); } catch {} playing = null; setChip(''); } }
async function playWav(buf) {
  stopSpeaking();
  try {
    const c = audioCtx();
    if (c.state !== 'running') await c.resume();
    const ab = await c.decodeAudioData(buf.buffer ? buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) : buf.slice(0));
    const src = c.createBufferSource();
    src.buffer = ab; src.connect(c.destination);
    playing = src; setChip('SPEAKING');
    src.addEventListener('ended', () => { if (playing === src) { playing = null; setChip(''); } });
    src.start(c.currentTime + 0.1);
    window.blink.speechPlayed(true);
  } catch (e) { playing = null; setChip(''); say(`Voice could not play: ${e && e.name}`, true); window.blink.speechPlayed(false, e && e.name); }
}
window.blink.onSpeechPlay(playWav);
window.blink.onSpeechStop(stopSpeaking);

let rec = null;
async function startListening() {
  if (rec) return;
  stopSpeaking();
  rec = { chunks: [], pending: true };
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true } });
    if (!rec) { stream.getTracks().forEach((t) => t.stop()); return; }
    const ctx = new AudioContext({ sampleRate: 16000 });
    const src = ctx.createMediaStreamSource(stream);
    const node = ctx.createScriptProcessor(4096, 1, 1);
    const mute = ctx.createGain(); mute.gain.value = 0;
    node.onaudioprocess = (e) => {
      if (!rec) return;
      const d = new Float32Array(e.inputBuffer.getChannelData(0));
      rec.chunks.push(d);
      let sum = 0, pk = 0; for (let i = 0; i < d.length; i++) { const a = Math.abs(d[i]); sum += a * a; if (a > pk) pk = a; }
      rec.level = Math.sqrt(sum / d.length); rec.peak = Math.max(rec.peak || 0, pk);
    };
    src.connect(node); node.connect(mute); mute.connect(ctx.destination);
    Object.assign(rec, { stream, ctx, src, node, pending: false });
    setChip('LISTENING');
    rec.t0 = Date.now();
    rec.meter = setInterval(() => {
      if (!rec) return;
      if (Date.now() - rec.t0 > 45000) { stopListening(false); return; }
      const n = Math.min(24, Math.round(Math.sqrt(rec.level || 0) * 40));
      const secs = Math.floor((Date.now() - rec.t0) / 1000);
      say(`REC ${String(Math.floor(secs / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}  [${'#'.repeat(n)}${'.'.repeat(24 - n)}]  ${n < 1 ? 'NO SOUND YET' : 'HEARING YOU'}  RELEASE OR TAP THE KEY AGAIN TO FINISH`);
    }, 80);
  } catch { rec = null; setChip(''); say('Microphone not available. Check Windows microphone privacy settings.', true); }
}
async function stopListening(send) {
  const r = rec; rec = null;
  if (!r) return;
  if (r.meter) clearInterval(r.meter);
  if (r.pending || !r.ctx) { setChip(''); return; }
  r.node.disconnect(); r.src.disconnect(); r.stream.getTracks().forEach((t) => t.stop());
  const rate = r.ctx.sampleRate; r.ctx.close();
  const n = r.chunks.reduce((a, c) => a + c.length, 0);
  if (n < rate * 0.4) { setChip(''); say('Too short. Hold the key while you speak.'); return; }
  const all = new Float32Array(n); let o = 0; for (const c of r.chunks) { all.set(c, o); o += c.length; }
  setChip('HEARING...');
  const quiet = (r.peak || 0) < 0.01;
  say(quiet ? 'THINKING... (THE MICROPHONE HEARD NEAR SILENCE: CHECK WHICH MIC WINDOWS IS USING)' : 'THINKING...');
  const res = await window.blink.speechListen(all, rate, send);
  setChip('');
  if (!res.ok) return say(res.error === 'LISTENER_NOT_INSTALLED' ? 'The voice pack is not installed yet.' : `Could not hear that (${res.error}).`, true);
  say(res.text ? `HEARD: ${res.text}${res.placed ? '' : '  (NO TEXT BOX HAS FOCUS: CLICK IN ONE FIRST)'}` : 'Heard nothing.', !!res.text && !res.placed);
}
window.blink.onPushToTalk(({ down, send }) => (down ? startListening() : stopListening(send)));

// ---- Keyboard: arrows and Tab move, digits jump, PgUp/PgDn page, Esc backs out ----
document.addEventListener('keydown', (e) => {
  if (e.key === 'F1') { e.preventDefault(); return go('shelf'); }
  if (e.key === 'F2') { e.preventDefault(); return go('admin'); }
  if (e.key === 'F3') { e.preventDefault(); return go('betty'); }
  if (S.active) return;
  const inInput = e.target && e.target.tagName === 'INPUT';
  const items = [...document.querySelectorAll('#view .k:not(:disabled), #view input, #keys .k')];
  const at = items.indexOf(document.activeElement);
  const move = (d) => { if (items.length) items[(at + d + items.length) % items.length].focus(); };
  if (e.key === 'ArrowDown' || (!inInput && e.key === 'ArrowRight')) { e.preventDefault(); return move(1); }
  if (e.key === 'ArrowUp' || (!inInput && e.key === 'ArrowLeft')) { e.preventDefault(); return move(-1); }
  if (e.key === 'PageDown' || e.key === 'PageUp') { const b = document.querySelector(`#view [data-page="${e.key === 'PageDown' ? 'next' : 'prev'}"]`); if (b) { e.preventDefault(); b.click(); } return; }
  if (e.key === 'Escape') { e.preventDefault(); return go(['keys', 'carts', 'voice', 'audit', 'usage', 'models'].includes(S.screen) ? 'admin' : 'shelf'); }
  if (!inInput && /^[1-9]$/.test(e.key)) { const b = document.querySelector(`#view [data-hot="${e.key}"]`); if (b && !b.disabled) { e.preventDefault(); b.click(); } }
});
window.addEventListener('contextmenu', (e) => e.preventDefault());

const tick = () => { const d = new Date(); $('#clock').textContent = d.toTimeString().slice(0, 5); };
tick(); setInterval(tick, 20000);
keysBar();
drawShelf();
window.blink.appVersion().then((v) => { const n = document.querySelector('#top .sub'); if (n && v) n.textContent = `LABYRINTH TERMINAL  VERSION ${v}`; }).catch(() => {});
audioCtx(); // wake the sound path early
refreshCost();
window.blink.updateState().then((u) => { if (u) { S.update = u; keysBar(); } }).catch(() => {});
window.blink.onUpdate((u) => { S.update = u; keysBar(); });
